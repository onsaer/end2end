// Test de bout en bout de l'extension : charge dist/extension dans Chromium,
// enregistre un parcours sur une page de démo façon Angular Material,
// sélectionne une zone et vérifie les étapes et les libellés/valeurs capturés.
//
//   npm run build && npm run test:e2e
//   (CHROMIUM_PATH=/chemin/vers/chrome pour choisir le navigateur)
import { chromium } from 'playwright-core';
import { createServer } from 'node:http';
import { readFileSync, mkdirSync, writeFileSync, mkdtempSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join, resolve } from 'node:path';
import assert from 'node:assert/strict';

const EXT = resolve('dist/extension');
const OUT = resolve('tests/output');
mkdirSync(OUT, { recursive: true });

const html = readFileSync(resolve('tests/fixture/index.html'));
const server = createServer((_req, res) => res.writeHead(200, { 'content-type': 'text/html; charset=utf-8' }).end(html));
await new Promise((r) => server.listen(0, r));
const base = `http://localhost:${server.address().port}`;

const ctx = await chromium.launchPersistentContext(mkdtempSync(join(tmpdir(), 'e2e-rec-')), {
  executablePath: process.env.CHROMIUM_PATH,
  headless: true,
  args: [`--disable-extensions-except=${EXT}`, `--load-extension=${EXT}`],
  viewport: { width: 1100, height: 900 },
});

try {
  const sw = ctx.serviceWorkers()[0] ?? (await ctx.waitForEvent('serviceworker'));
  const extId = new URL(sw.url()).host;

  const app = await ctx.newPage();
  await app.goto(base + '/inscription');

  const panel = await ctx.newPage();
  await panel.goto(`chrome-extension://${extId}/index.html`);
  const send = (msg) => panel.evaluate((m) => chrome.runtime.sendMessage(m), msg);
  const state = () => panel.evaluate(async () => (await chrome.storage.local.get('e2eRecorderState')).e2eRecorderState);
  const tabId = await panel.evaluate(async (u) => (await chrome.tabs.query({ url: u + '/*' }))[0].id, base);

  await send({ kind: 'start', tabId });
  await app.bringToFront();
  await app.waitForTimeout(300);

  // --- Parcours utilisateur ---
  await app.click('#mat-input-0');
  await app.keyboard.type('Dupont');
  await app.click('#mat-input-1');
  await app.keyboard.type('jean@exemple.fr');
  await app.click('#mat-input-2');
  await app.keyboard.type('secret123');
  await app.focus('#country');
  await app.keyboard.press('ArrowDown'); // événement « change » réel (selectOption est synthétique)
  await app.click('#mat-select-3');
  await app.click('text=Anglais');
  await app.click('label[for=mat-radio-3-input]');
  await app.click('label[for=mat-mdc-checkbox-1-input]');
  await app.click('#mat-mdc-slide-toggle-1-button');
  await app.click('#mat-input-4');
  await app.keyboard.type('Livraison le matin');
  await app.click('button[type=submit]');
  await app.waitForTimeout(500);

  let s = await state();
  writeFileSync(join(OUT, 'state.json'), JSON.stringify(s, null, 2));
  const types = s.steps.map((st) => st.type);
  console.log('Étapes :', types.join(', '));

  // --- Sélection d'une zone : rectangle tracé à la souris sur le récapitulatif ---
  await send({ kind: 'select-region' });
  await app.bringToFront();
  await app.waitForTimeout(300);
  const box = await app.locator('#recap').boundingBox();
  await app.mouse.move(box.x - 4, box.y - 4);
  await app.mouse.down();
  await app.mouse.move(box.x + box.width / 2, box.y + box.height / 2, { steps: 5 });
  await app.mouse.move(box.x + box.width + 4, box.y + box.height + 4, { steps: 5 });
  await app.mouse.up();
  await app.waitForTimeout(800);

  // --- Sélection d'un élément au clic : le formulaire d'identité ---
  await send({ kind: 'select-region' });
  await app.bringToFront();
  await app.waitForTimeout(300);
  const idBox = await app.locator('section.identity h2').boundingBox();
  await app.mouse.move(idBox.x + 2, idBox.y + 2);
  await app.keyboard.press('ArrowUp'); // remonte de <h2> à la <section>
  await app.keyboard.press('Enter');
  await app.waitForTimeout(800);

  s = await state();
  writeFileSync(join(OUT, 'state.json'), JSON.stringify(s, null, 2));


  const steps = s.steps;
  const find = (t, pred = () => true) => steps.find((st) => st.type === t && pred(st));
  assert.ok(find('navigate'), 'navigation initiale');
  assert.equal(find('input', (st) => st.target.css.includes('lastName'))?.value, 'Dupont');
  assert.equal(find('input', (st) => st.target.locator.value === 'Email')?.value, 'jean@exemple.fr');
  assert.ok(find('input', (st) => st.masked), 'mot de passe masqué');
  assert.equal(find('select')?.value, 'fr');
  assert.ok(find('click', (st) => st.target.text === 'Anglais'), 'clic sur option mat-select');
  assert.ok(find('check', (st) => st.target.label === 'Mme' && st.checked), 'radio Mme');
  assert.ok(find('check', (st) => st.target.label?.startsWith("J'accepte")), 'case à cocher');
  assert.ok(find('click', (st) => st.target.role === 'switch'), 'slide toggle');
  assert.equal(find('input', (st) => st.target.tag === 'textarea')?.value, 'Livraison le matin');
  assert.ok(find('click', (st) => st.target.locator.by === 'role' && st.target.locator.name === 'Enregistrer'), 'bouton Enregistrer');
  assert.ok(find('navigate', (st) => st.implicit && st.url.endsWith('/recap')), 'navigation SPA');
  assert.equal(steps.filter((st) => st.type === 'input' && st.target.css.includes('lastName')).length, 1, 'saisies regroupées');

  const snaps = steps.filter((st) => st.type === 'snapshot');
  assert.equal(snaps.length, 2, 'deux zones');
  const kv = (snap) => Object.fromEntries(snap.snapshot.entries.map((e) => [e.label, e.value]));
  const recap = kv(snaps[0]);
  console.log('Zone récap :', recap);
  assert.equal(recap['Nom'], 'Dupont');
  assert.equal(recap['Email'], 'jean@exemple.fr');
  assert.equal(recap['Statut'], 'Validé');
  assert.equal(recap['Langue'], 'Anglais');
  assert.equal(recap['Ligne 1 › Produit'], 'Clavier');
  assert.equal(recap['Ligne 2 › Prix'], '19,90 €');
  assert.ok(snaps[0].snapshot.screenshot?.startsWith('data:image/'), 'capture de la zone');

  const ident = kv(snaps[1]);
  console.log('Zone identité :', ident);
  assert.ok(snaps[1].snapshot.container, 'zone choisie par élément');
  assert.equal(ident['Nom'], 'Dupont');
  assert.equal(ident['Mot de passe'], '••••••');
  assert.equal(ident['Pays'], 'France');
  assert.equal(ident['Langue'], 'Anglais');
  assert.equal(ident['Civilité'], 'Mme');
  assert.equal(ident["J'accepte les conditions"], 'coché');
  assert.equal(ident['Newsletter'], 'coché');
  assert.equal(ident['Commentaire'], 'Livraison le matin');

  // --- Rejeu des interactions enregistrées dans un état vierge ---
  const replay = async (password) => {
    await send({ kind: 'replay-start', tabId, password });
    for (let i = 0; i < 200; i++) {
      await app.waitForTimeout(250);
      const r = (await state()).replay;
      if (r && !r.running && r.finishedAt) return r;
    }
    throw new Error('Rejeu trop long');
  };
  await app.goto('about:blank');
  let r = await replay('secret123');
  const status = (st) => r.results[st.id]?.status;
  for (const st of steps) {
    const res = r.results[st.id];
    console.log(`  rejeu ${st.type.padEnd(9)} ${res?.status}${res?.message ? ' : ' + res.message : ''}`);
    assert.ok(res && (res.status === 'ok' || (st.type === 'submit' && res.status === 'skipped')), `étape ${st.type} rejouée`);
  }
  assert.equal(await app.locator('#mat-input-2').inputValue(), 'secret123', 'mot de passe rejoué');
  assert.equal(await app.locator('#mat-select-3').innerText(), 'Anglais', 'mat-select rejoué');
  for (const snap of snaps) assert.ok(r.results[snap.id].checks.every((c) => c.ok), 'zone vérifiée au rejeu');

  // Une valeur attendue qui ne correspond plus doit faire échouer la vérification.
  const tampered = structuredClone(steps);
  const statut = tampered.find((st) => st.type === 'snapshot').snapshot.entries.find((e) => e.label === 'Statut');
  statut.value = 'Refusé';
  statut.raw = 'Statut : Refusé';
  await send({ kind: 'import', steps: tampered });
  await app.goto('about:blank');
  await send({ kind: 'settings', settings: { replayDelay: 0 } });
  r = await replay('secret123');
  const snapRes = r.results[tampered.find((st) => st.type === 'snapshot').id];
  console.log('  rejeu modifié :', snapRes.status, snapRes.message);
  assert.equal(snapRes.status, 'fail');
  assert.equal(snapRes.checks.find((c) => c.entryId === statut.id).actual, 'Statut : Validé');
  void status;
  await panel.bringToFront();
  await panel.setViewportSize({ width: 420, height: 1700 });
  await panel.waitForTimeout(300);
  await panel.screenshot({ path: join(OUT, 'panel-replay.png'), fullPage: true });
  await send({ kind: 'import', steps });

  // --- Panneau latéral : rendu et génération de code ---
  await panel.bringToFront();
  await panel.setViewportSize({ width: 420, height: 1400 });
  await panel.waitForTimeout(300);
  await panel.screenshot({ path: join(OUT, 'panel-steps.png'), fullPage: true });
  await panel.click('text=Script de test');
  const code = await panel.locator('pre code').innerText();
  writeFileSync(join(OUT, 'generated.spec.ts'), code);
  await panel.screenshot({ path: join(OUT, 'panel-code.png') });
  assert.match(code, /getByLabel\("Nom", \{ exact: true \}\)\.fill\("Dupont"\)/);
  assert.doesNotMatch(code, /toHaveURL/);
  assert.match(code, /toHaveText\("Statut : Validé"\)/);

  console.log('\n✔ Tous les contrôles sont passés. Sorties dans tests/output/');
} finally {
  await ctx.close();
  server.close();
}
