// Compile le service worker et le content script (hors Angular) avec esbuild,
// puis vérifie que le dossier dist/extension est chargeable dans Chrome.
import { build, context } from 'esbuild';
import { existsSync } from 'node:fs';

const watch = process.argv.includes('--watch');
const outdir = 'dist/extension';
const options = {
  entryPoints: { background: 'src/extension/background.ts', content: 'src/extension/content.ts' },
  outdir,
  bundle: true,
  format: 'iife',
  target: 'chrome116',
  minify: !watch,
  sourcemap: watch ? 'inline' : false,
  logLevel: 'info',
};

if (watch) {
  const ctx = await context(options);
  await ctx.watch();
} else {
  await build(options);
  for (const f of ['manifest.json', 'index.html', 'background.js', 'content.js']) {
    if (!existsSync(`${outdir}/${f}`)) {
      console.error(`Fichier manquant : ${outdir}/${f}`);
      process.exit(1);
    }
  }
  console.log(`\nExtension prête : chargez le dossier « ${outdir} » via chrome://extensions › Charger l'extension non empaquetée.`);
}
