"""Génère les icônes PNG de l'extension (pastille d'enregistrement + cadre de sélection)."""
import struct, zlib, os, sys

def png(size):
    rows = []
    s = size
    for y in range(s):
        row = bytearray([0])
        for x in range(s):
            cx, cy = x + .5, y + .5
            # fond carré arrondi sombre
            r = s * .2
            dx = max(r - cx, 0, cx - (s - r)); dy = max(r - cy, 0, cy - (s - r))
            inside = dx*dx + dy*dy <= r*r
            col = (0, 0, 0, 0)
            if inside:
                col = (31, 35, 48, 255)
                # cadre pointillé de sélection
                m = s * .16; w = max(1, s * .06)
                on_edge = (m <= cx <= s-m and m <= cy <= s-m) and (cx < m+w or cx > s-m-w or cy < m+w or cy > s-m-w)
                dash = int((cx + cy) / max(2, s*.12)) % 2 == 0
                if on_edge and dash:
                    col = (100, 181, 246, 255)
                # pastille rouge centrale
                d = ((cx - s/2)**2 + (cy - s/2)**2) ** .5
                if d <= s * .2:
                    col = (229, 57, 53, 255)
            row += bytes(col)
        rows.append(bytes(row))
    raw = b''.join(rows)
    def chunk(t, d): return struct.pack('>I', len(d)) + t + d + struct.pack('>I', zlib.crc32(t + d) & 0xffffffff)
    return b'\x89PNG\r\n\x1a\n' + chunk(b'IHDR', struct.pack('>IIBBBBB', s, s, 8, 6, 0, 0, 0)) + chunk(b'IDAT', zlib.compress(raw, 9)) + chunk(b'IEND', b'')

out = sys.argv[1]
os.makedirs(out, exist_ok=True)
for n in (16, 32, 48, 128):
    open(os.path.join(out, f'icon{n}.png'), 'wb').write(png(n))
