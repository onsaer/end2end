# E2E Recorder : extension Chrome pour tests end-to-end

Extension Chrome (Manifest V3) qui enregistre les interactions d'un utilisateur dans une application web et capture tous les libellés et valeurs d'une zone sélectionnée. Elle génère ensuite un test **Playwright** ou **Cypress** (ou un scénario JSON). Le panneau latéral est une application **Angular 22** (composants standalone, signals, zoneless).

## Installation (mode développeur)

1. `npm install` puis `npm run build` (Node ≥ 22.22.3 ou ≥ 24.15, exigé par Angular CLI 22).
2. Ouvrir `chrome://extensions`, activer le **Mode développeur**.
3. Cliquer sur **Charger l'extension non empaquetée** et choisir le dossier `dist/extension`.
4. Épingler l'icône « E2E Recorder » puis cliquer dessus : le panneau latéral s'ouvre.

Un build prêt à charger est aussi fourni dans `e2e-recorder-extension.zip` (le décompresser puis charger le dossier).

## Utilisation

- **● Enregistrer** : enregistre l'onglet actif. Sont capturés : clics, double-clics, saisies (regroupées en une valeur finale), listes `<select>`, cases à cocher, boutons radio, touches spéciales (Entrée, Échap, Tab, flèches, raccourcis Ctrl/Cmd), soumissions de formulaires, navigations (URL saisie, liens, routes SPA Angular via `history.pushState`).
- **⬚ Sélectionner une zone** (ou `Alt+Maj+S`) :
  - glisser pour tracer un rectangle, **ou**
  - survoler et cliquer sur un bloc (`↑` remonte au parent, `Entrée` valide, `Échap` annule).
  
  Tous les libellés et valeurs de la zone sont enregistrés, avec une capture d'écran de la zone :
  champs (`input`, `textarea`, `select`), composants Angular Material (`mat-form-field`/`mat-label`, `mat-select`, `mat-checkbox`, `mat-radio-group`, `mat-slide-toggle`, `mat-card-title`, `mat-chip`, `mat-table`…), rôles ARIA (combobox, checkbox, switch, slider…), listes de définitions `dl/dt/dd`, tableaux (en-tête de colonne × ligne), couples « Libellé : valeur » et texte libre (titres, messages, erreurs).
- **▶ Rejouer** : réexécute les étapes dans l'onglet actif (ouverture de l'URL, clics, saisies, listes, cases, touches) et revérifie chaque zone en comparant les valeurs actuelles aux valeurs enregistrées. Chaque étape affiche ✓ réussie, ✗ échec (avec la valeur obtenue) ou ⤼ ignorée, et un bilan s'affiche en haut du panneau. Le bouton ▶ d'une étape rejoue à partir de celle-ci. Options : vitesse (rapide, normale, lente), arrêt au premier échec, et mot de passe à utiliser pour les saisies masquées (gardé en mémoire du panneau, jamais enregistré). Les éléments rejoués sont surlignés dans la page.
- **Script de test** : Playwright (TypeScript), Cypress ou JSON brut ; copier ou télécharger. Chaque zone devient une série d'assertions (`toHaveValue`, `toBeChecked`, `toHaveText`…).
- Les mots de passe sont masqués par défaut ; le script Playwright lit alors `process.env.E2E_PASSWORD` (Cypress : `Cypress.env('E2E_PASSWORD')`).
- **Importer / Effacer** : recharger un scénario JSON exporté, ou repartir de zéro. Chaque étape et chaque valeur capturée peut être supprimée individuellement.

## Choix des sélecteurs

Par ordre de préférence : `data-testid` / `data-cy` / `data-test`…, libellé associé (`getByLabel`, compatible avec le `<label for>` généré par `mat-form-field`), rôle + nom accessible (`getByRole`), placeholder, puis CSS stable. Les identifiants générés par Angular Material/CDK (`mat-input-0`, `cdk-overlay-…`) et les classes techniques (`ng-*`, `mat-mdc-*`) sont ignorés ; `formcontrolname` est utilisé quand il est présent.

## Structure

```
public/manifest.json         Manifest V3 (panneau latéral, raccourci, permissions)
src/extension/background.ts  Service worker : état, navigation, capture d'écran
src/extension/content.ts     Enregistreur d'interactions (toutes pages et iframes)
src/extension/region.ts      Calque de sélection de zone
src/extension/snapshot.ts    Extraction des libellés et valeurs d'une zone
src/extension/dom.ts         Sélecteurs, libellés accessibles, valeurs
src/shared/                  Types partagés et générateurs Playwright/Cypress
src/app/                     Panneau latéral Angular 22
tests/                       Test automatisé (Chromium + page de démo)
```

## Développement

- `npm run watch` (panneau Angular) et `npm run watch:scripts` (service worker + content script), puis « Actualiser » dans `chrome://extensions`.
- `npm run test:e2e` : charge l'extension dans Chromium, rejoue un parcours sur `tests/fixture/index.html`, vérifie les étapes et les valeurs capturées, et écrit le script généré et des captures du panneau dans `tests/output/`. Nécessite `playwright-core` (devDependency) et un Chromium (`CHROMIUM_PATH=/chemin/vers/chrome`).

## Limites connues

- Le rejeu dans l'extension simule les événements DOM (compatibles Angular, formulaires réactifs et Angular Material) ; les sélections de fichiers et les étapes dans des iframes sont ignorées. Pour un rejeu en CI, utiliser le script Playwright généré.

- La sélection de zone porte sur le cadre principal ; les interactions dans les iframes sont enregistrées mais le script les signale en commentaire.
- Les shadow DOM fermés ne sont pas lisibles ; les shadow DOM ouverts sont parcourus.
- Les pages internes de Chrome (`chrome://`, Chrome Web Store) ne peuvent pas être enregistrées.
