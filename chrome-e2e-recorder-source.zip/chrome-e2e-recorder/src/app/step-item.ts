import { Component, computed, inject, input, signal } from '@angular/core';
import { describeStep } from '../shared/codegen';
import type { Step } from '../shared/types';
import { RecorderService } from './recorder.service';

const ICONS: Record<Step['type'], string> = {
  navigate: '↗',
  click: '👆',
  dblclick: '👆',
  input: '⌨',
  select: '☰',
  check: '☑',
  keypress: '⏎',
  submit: '✉',
  snapshot: '⬚',
};

const KIND_LABEL: Record<string, string> = {
  input: 'champ',
  textarea: 'zone de texte',
  select: 'liste',
  checkbox: 'case',
  radio: 'choix',
  combobox: 'liste',
  slider: 'curseur',
  editable: 'éditable',
  pair: 'libellé',
  table: 'tableau',
  text: 'texte',
};

@Component({
  selector: 'app-step-item',
  template: `
    <article [class]="'step ' + (result()?.status ?? '')" [class.snap]="step().type === 'snapshot'">
      <div class="row">
        <span class="num">{{ index() }}</span>
        @if (result(); as r) {
          <span class="badge {{ r.status }}" [title]="statusLabel(r.status)">{{ statusIcon(r.status) }}</span>
        }
        <span class="icon" aria-hidden="true">{{ icon() }}</span>
        <div class="grow">
          <div class="desc">{{ description() }}</div>
          <div class="meta">
            {{ time() }}
            @if (step().target; as t) {
              · <code [title]="t.css">{{ t.css }}</code>
            }
          </div>
          @if (result()?.message; as m) {
            <div class="replay-msg">{{ m }}</div>
          }
        </div>
        <button class="icon-btn" (click)="rec.replayFrom(index() - 1)" [disabled]="rec.replaying()" title="Rejouer à partir de cette étape">▶</button>
        @if (step().snapshot) {
          <button class="icon-btn" (click)="open.set(!open())" [title]="open() ? 'Replier' : 'Déplier'">{{ open() ? '▾' : '▸' }}</button>
        }
        <button class="icon-btn" (click)="rec.deleteStep(step().id)" title="Supprimer l'étape">✕</button>
      </div>

      @if (step().snapshot; as snap) {
        @if (open()) {
          <div class="snapshot">
            <input class="name" [value]="snap.name" (change)="rename($event)" aria-label="Nom de la zone" />
            @if (snap.screenshot) {
              <img [src]="snap.screenshot" alt="Capture de la zone sélectionnée" />
            }
            @if (snap.entries.length) {
              <table>
                <thead>
                  <tr><th>Libellé</th><th>Valeur</th>@if (checks()) {<th>Rejeu</th>}<th></th></tr>
                </thead>
                <tbody>
                  @for (e of snap.entries; track e.id) {
                    <tr>
                      <td>
                        {{ e.label || '—' }}
                        <span class="kind">{{ kindLabel(e.kind) }}</span>
                      </td>
                      <td class="val" [title]="e.target.css">{{ e.value === '' ? '(vide)' : e.value }}</td>
                      @if (checks(); as c) {
                        @if (c[e.id]; as chk) {
                          <td class="check" [class.ko]="!chk.ok">{{ chk.ok ? '✓' : '✗ ' + (chk.actual === '' ? '(vide)' : chk.actual) }}</td>
                        } @else {
                          <td></td>
                        }
                      }
                      <td><button class="icon-btn" (click)="rec.deleteEntry(step().id, e.id)" title="Retirer cette valeur">✕</button></td>
                    </tr>
                  }
                </tbody>
              </table>
            } @else {
              <p class="muted">Aucun libellé ni valeur trouvé dans cette zone.</p>
            }
          </div>
        }
      }
    </article>
  `,
})
export class StepItem {
  protected readonly rec = inject(RecorderService);
  readonly step = input.required<Step>();
  readonly index = input.required<number>();
  protected readonly open = signal(true);

  protected readonly result = computed(() => this.rec.replay()?.results[this.step().id]);
  protected readonly checks = computed(() => {
    const c = this.result()?.checks;
    return c ? Object.fromEntries(c.map((x) => [x.entryId, x])) : null;
  });

  protected statusIcon(s: string): string {
    return { running: '⏳', ok: '✓', fail: '✗', skipped: '⤼' }[s] ?? '';
  }
  protected statusLabel(s: string): string {
    return { running: 'En cours', ok: 'Réussie', fail: 'Échec', skipped: 'Ignorée' }[s] ?? '';
  }

  protected readonly icon = computed(() => ICONS[this.step().type]);
  protected readonly description = computed(() => describeStep(this.step()));
  protected readonly time = computed(() => new Date(this.step().timestamp).toLocaleTimeString('fr-FR'));

  protected kindLabel(k: string): string {
    return KIND_LABEL[k] ?? k;
  }

  protected rename(ev: Event): void {
    const name = (ev.target as HTMLInputElement).value.trim();
    if (name) void this.rec.renameSnapshot(this.step().id, name);
  }
}
