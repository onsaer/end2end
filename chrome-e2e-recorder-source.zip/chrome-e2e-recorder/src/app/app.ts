import { Component, computed, inject, signal } from '@angular/core';
import { toCypress, toPlaywright } from '../shared/codegen';
import type { Step } from '../shared/types';
import { RecorderService } from './recorder.service';
import { StepItem } from './step-item';

type Tab = 'steps' | 'code';
type Format = 'playwright' | 'cypress' | 'json';

@Component({
  selector: 'app-root',
  imports: [StepItem],
  templateUrl: './app.html',
})
export class App {
  protected readonly rec = inject(RecorderService);
  protected readonly tab = signal<Tab>('steps');
  protected readonly format = signal<Format>('playwright');
  protected readonly testName = signal('scénario enregistré');
  protected readonly copied = signal(false);

  protected readonly code = computed(() => {
    const steps = this.rec.steps();
    switch (this.format()) {
      case 'playwright':
        return toPlaywright(steps, this.testName());
      case 'cypress':
        return toCypress(steps, this.testName());
      case 'json':
        return JSON.stringify({ name: this.testName(), version: 1, steps }, null, 2);
    }
  });

  protected readonly fileName = computed(() => {
    const base = this.testName().normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/[^\w]+/g, '-').replace(/^-|-$/g, '').toLowerCase() || 'scenario';
    return { playwright: `${base}.spec.ts`, cypress: `${base}.cy.ts`, json: `${base}.json` }[this.format()];
  });

  protected readonly status = computed(() => {
    if (this.rec.selecting()) return { cls: 'select', text: 'Sélection de zone…' };
    if (this.rec.recording()) return this.rec.paused() ? { cls: 'pause', text: 'En pause' } : { cls: 'rec', text: 'Enregistrement' };
    return { cls: 'idle', text: 'Arrêté' };
  });

  protected async copy(): Promise<void> {
    await navigator.clipboard.writeText(this.code());
    this.copied.set(true);
    setTimeout(() => this.copied.set(false), 1500);
  }

  protected download(): void {
    const blob = new Blob([this.code()], { type: this.format() === 'json' ? 'application/json' : 'text/plain' });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = this.fileName();
    a.click();
    setTimeout(() => URL.revokeObjectURL(a.href), 1000);
  }

  protected async importFile(ev: Event): Promise<void> {
    const input = ev.target as HTMLInputElement;
    const file = input.files?.[0];
    input.value = '';
    if (!file) return;
    try {
      const data = JSON.parse(await file.text());
      const steps: Step[] = Array.isArray(data) ? data : data.steps;
      if (!Array.isArray(steps)) throw new Error('format');
      if (data.name) this.testName.set(data.name);
      await this.rec.importSteps(steps);
    } catch {
      alert('Fichier JSON invalide : il doit provenir d’un export de cette extension.');
    }
  }

  protected confirmClear(): void {
    if (confirm('Effacer toutes les étapes enregistrées ?')) void this.rec.clear();
  }
}
