import { Injectable, computed, signal } from '@angular/core';
import { DEFAULT_STATE, STATE_KEY, type Message, type RecorderState, type Settings, type Step } from '../shared/types';

/** Façade signal sur l'état stocké par le service worker. */
@Injectable({ providedIn: 'root' })
export class RecorderService {
  private readonly ext = typeof chrome !== 'undefined' && !!chrome.storage?.local;

  readonly state = signal<RecorderState>(DEFAULT_STATE);
  readonly steps = computed(() => this.state().steps);
  readonly recording = computed(() => this.state().recording);
  readonly paused = computed(() => this.state().paused);
  readonly selecting = computed(() => this.state().selecting);
  readonly settings = computed(() => this.state().settings);
  readonly replay = computed(() => this.state().replay);
  readonly replaying = computed(() => !!this.state().replay?.running);
  readonly hasMaskedInput = computed(() => this.steps().some((s) => s.type === 'input' && s.masked));
  /** Mot de passe pour le rejeu : gardé en mémoire du panneau, jamais stocké. */
  readonly replayPassword = signal('');
  readonly replaySummary = computed(() => {
    const r = this.replay();
    if (!r) return null;
    const res = Object.values(r.results);
    return {
      running: r.running,
      stopped: !!r.stopped,
      ok: res.filter((x) => x.status === 'ok').length,
      fail: res.filter((x) => x.status === 'fail').length,
      skipped: res.filter((x) => x.status === 'skipped').length,
      current: (r.current ?? 0) + 1,
      total: this.steps().length,
    };
  });
  readonly snapshotCount = computed(() => this.steps().filter((s) => s.type === 'snapshot').length);

  constructor() {
    if (!this.ext) return;
    chrome.storage.local.get(STATE_KEY).then((r) => this.apply(r[STATE_KEY] as RecorderState | undefined));
    chrome.storage.onChanged.addListener((changes, area) => {
      if (area === 'local' && STATE_KEY in changes) this.apply(changes[STATE_KEY].newValue as RecorderState | undefined);
    });
  }

  private apply(s: RecorderState | undefined): void {
    this.state.set(s ? { ...DEFAULT_STATE, ...s, settings: { ...DEFAULT_STATE.settings, ...s.settings } } : DEFAULT_STATE);
  }

  private async send(msg: Message): Promise<void> {
    if (this.ext) await chrome.runtime.sendMessage(msg);
  }

  private async activeTabId(): Promise<number | undefined> {
    if (!this.ext) return undefined;
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    return tab?.id;
  }

  async start(): Promise<void> {
    const tabId = await this.activeTabId();
    if (tabId !== undefined) await this.send({ kind: 'start', tabId });
  }
  stop = () => this.send({ kind: 'stop' });
  togglePause = () => this.send({ kind: 'pause', paused: !this.paused() });
  clear = () => this.send({ kind: 'clear' });
  async selectRegion(): Promise<void> {
    await this.send({ kind: 'select-region', tabId: await this.activeTabId() });
  }
  async replayFrom(fromIndex = 0): Promise<void> {
    // Rejeu dans l'onglet actif de la fenêtre du panneau.
    const tabId = await this.activeTabId();
    if (tabId !== undefined) await this.send({ kind: 'replay-start', tabId, password: this.replayPassword() || undefined, fromIndex });
  }
  stopReplay = () => this.send({ kind: 'replay-stop' });
  cancelSelection = () => this.send({ kind: 'cancel-selection' });
  deleteStep = (id: string) => this.send({ kind: 'delete-step', id });
  deleteEntry = (stepId: string, entryId: string) => this.send({ kind: 'delete-entry', stepId, entryId });
  renameSnapshot = (stepId: string, name: string) => this.send({ kind: 'rename-snapshot', stepId, name });
  importSteps = (steps: Step[]) => this.send({ kind: 'import', steps });
  updateSettings = (settings: Partial<Settings>) => this.send({ kind: 'settings', settings });
}
