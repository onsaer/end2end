/**
 * Service worker : source de vérité de l'enregistrement (chrome.storage.local),
 * navigation, captures d'écran et coordination panneau <-> pages.
 */
import { DEFAULT_STATE, STATE_KEY, uid, type Message, type RecorderState, type ReplayResponse, type Snapshot, type Step, type StepResult } from '../shared/types';

// --- État sérialisé : chaque mutation passe par une file pour éviter les courses. ---
let queue: Promise<unknown> = Promise.resolve();

async function readState(): Promise<RecorderState> {
  const r = await chrome.storage.local.get(STATE_KEY);
  const s = r[STATE_KEY] as RecorderState | undefined;
  return s ? { ...DEFAULT_STATE, ...s, settings: { ...DEFAULT_STATE.settings, ...s.settings } } : structuredClone(DEFAULT_STATE);
}

function update(fn: (s: RecorderState) => void | Promise<void>): Promise<RecorderState> {
  const run = queue.then(async () => {
    const s = await readState();
    await fn(s);
    await chrome.storage.local.set({ [STATE_KEY]: s });
    return s;
  });
  queue = run.catch((e) => console.error('[e2e-recorder]', e));
  return run;
}

// --- Fusion des étapes successives ---
function pushStep(s: RecorderState, step: Step): void {
  const last = s.steps[s.steps.length - 1];
  const sameTarget = last?.target && step.target && last.target.css === step.target.css && last.target.frameUrl === step.target.frameUrl;

  if (step.type === 'input' && last?.type === 'input' && sameTarget) {
    last.value = step.value;
    last.masked = step.masked;
    last.timestamp = step.timestamp;
    return;
  }
  // Clic pour focaliser un champ juste avant d'y saisir : la saisie suffit.
  if (step.type === 'input' && last?.type === 'click' && sameTarget) s.steps.pop();
  if (step.type === 'dblclick') {
    for (let i = 0; i < 2; i++) {
      const prev = s.steps[s.steps.length - 1];
      if (prev?.type === 'click' && prev.target?.css === step.target?.css && step.timestamp - prev.timestamp < 800) s.steps.pop();
    }
  }
  if (step.type === 'navigate' && last?.type === 'navigate' && last.url === step.url) return;
  s.steps.push(step);
}

// --- Injection du content script dans les onglets ouverts avant l'installation ---
async function ensureInjected(tabId: number): Promise<boolean> {
  try {
    await chrome.tabs.sendMessage(tabId, { kind: 'ping' } satisfies Message, { frameId: 0 });
    return true;
  } catch {
    try {
      await chrome.scripting.executeScript({ target: { tabId, allFrames: true }, files: ['content.js'] });
      return true;
    } catch (e) {
      console.warn('[e2e-recorder] injection impossible', e);
      return false;
    }
  }
}

async function startSelection(tabId: number | undefined): Promise<void> {
  const s = await readState();
  const target = s.recording && s.tabId !== undefined ? s.tabId : tabId ?? (await activeTabId());
  if (target === undefined) return;
  if (!(await ensureInjected(target))) return;
  await update((st) => {
    st.selecting = true;
    if (!st.recording) st.tabId = target;
  });
  await chrome.tabs.update(target, { active: true });
  await chrome.tabs.sendMessage(target, { kind: 'start-selection' } satisfies Message, { frameId: 0 }).catch(() => undefined);
}

async function activeTabId(): Promise<number | undefined> {
  const [tab] = await chrome.tabs.query({ active: true, lastFocusedWindow: true });
  return tab?.id;
}

async function captureRegion(tabId: number, snapshot: Snapshot, viewportWidth: number): Promise<string | undefined> {
  try {
    const tab = await chrome.tabs.get(tabId);
    const dataUrl = await chrome.tabs.captureVisibleTab(tab.windowId, { format: 'png' });
    const blob = await (await fetch(dataUrl)).blob();
    const full = await createImageBitmap(blob);
    const scale = full.width / viewportWidth;
    const { x, y, width, height } = snapshot.rect;
    const sx = Math.max(0, Math.round(x * scale));
    const sy = Math.max(0, Math.round(y * scale));
    const sw = Math.min(full.width - sx, Math.round(width * scale));
    const sh = Math.min(full.height - sy, Math.round(height * scale));
    if (sw <= 0 || sh <= 0) return undefined;
    const ratio = Math.min(1, 900 / sw);
    const canvas = new OffscreenCanvas(Math.round(sw * ratio), Math.round(sh * ratio));
    canvas.getContext('2d')!.drawImage(full, sx, sy, sw, sh, 0, 0, canvas.width, canvas.height);
    const out = await canvas.convertToBlob({ type: 'image/webp', quality: 0.85 });
    const bytes = new Uint8Array(await out.arrayBuffer());
    let bin = '';
    for (let i = 0; i < bytes.length; i += 0x8000) bin += String.fromCharCode(...bytes.subarray(i, i + 0x8000));
    return `data:image/webp;base64,${btoa(bin)}`;
  } catch (e) {
    console.warn('[e2e-recorder] capture impossible', e);
    return undefined;
  }
}

// --- Messages ---
chrome.runtime.onMessage.addListener((msg: Message, sender, sendResponse) => {
  handle(msg, sender).then(
    (r) => sendResponse(r ?? { ok: true }),
    (e) => sendResponse({ ok: false, error: String(e) }),
  );
  return true;
});

async function handle(msg: Message, sender: chrome.runtime.MessageSender): Promise<unknown> {
  const fromTab = sender.tab?.id;
  switch (msg.kind) {
    case 'start': {
      await ensureInjected(msg.tabId);
      const tab = await chrome.tabs.get(msg.tabId);
      await update((s) => {
        s.recording = true;
        s.paused = false;
        s.replay = undefined;
        s.tabId = msg.tabId;
        s.startedAt ??= Date.now();
        const last = [...s.steps].reverse().find((st) => st.type !== 'snapshot');
        if (tab.url && (!last || last.url !== tab.url)) {
          pushStep(s, { id: uid(), type: 'navigate', timestamp: Date.now(), url: tab.url, title: tab.title });
        }
      });
      return;
    }
    case 'stop':
      await update((s) => {
        s.recording = false;
        s.paused = false;
      });
      return;
    case 'pause':
      await update((s) => void (s.paused = msg.paused));
      return;
    case 'replay-start':
      void runReplay(msg.tabId, msg.password, msg.fromIndex ?? 0);
      return;
    case 'replay-stop':
      replayAbort = true;
      return;
    case 'clear':
      await update((s) => {
        s.replay = undefined;
        s.steps = [];
        s.startedAt = s.recording ? Date.now() : undefined;
      });
      return;
    case 'delete-step':
      await update((s) => void (s.steps = s.steps.filter((st) => st.id !== msg.id)));
      return;
    case 'delete-entry':
      await update((s) => {
        const st = s.steps.find((x) => x.id === msg.stepId);
        if (st?.snapshot) st.snapshot.entries = st.snapshot.entries.filter((e) => e.id !== msg.entryId);
      });
      return;
    case 'rename-snapshot':
      await update((s) => {
        const st = s.steps.find((x) => x.id === msg.stepId);
        if (st?.snapshot) st.snapshot.name = msg.name;
      });
      return;
    case 'import':
      await update((s) => {
        s.steps = msg.steps;
        s.replay = undefined;
      });
      return;
    case 'settings':
      await update((s) => void (s.settings = { ...s.settings, ...msg.settings }));
      return;
    case 'select-region':
      await startSelection(msg.tabId);
      return;
    case 'cancel-selection': {
      const s = await update((st) => void (st.selecting = false));
      if (s.tabId !== undefined) await chrome.tabs.sendMessage(s.tabId, { kind: 'stop-selection' } satisfies Message, { frameId: 0 }).catch(() => undefined);
      return;
    }
    case 'selection-ended':
      await update((s) => void (s.selecting = false));
      return;
    case 'snapshot': {
      if (fromTab === undefined) return;
      const screenshot = await captureRegion(fromTab, msg.snapshot, msg.viewportWidth);
      await update((s) => {
        s.selecting = false;
        pushStep(s, {
          id: uid(),
          type: 'snapshot',
          timestamp: Date.now(),
          url: msg.url,
          title: msg.title,
          snapshot: { ...msg.snapshot, screenshot },
        });
      });
      return;
    }
    case 'step': {
      const s = await readState();
      if (!s.recording || s.paused || fromTab !== s.tabId) return;
      await update((st) => pushStep(st, msg.step));
      return;
    }
  }
  return;
}

// --- Rejeu ---
let replayAbort = false;
const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));
const ACTION_TIMEOUT = 8000;

async function waitForLoad(tabId: number, timeout = 20000): Promise<void> {
  const end = Date.now() + timeout;
  while (Date.now() < end) {
    const tab = await chrome.tabs.get(tabId);
    if (tab.status === 'complete') return;
    await sleep(100);
  }
}

async function sendStep(tabId: number, step: Step, password?: string): Promise<ReplayResponse> {
  const end = Date.now() + ACTION_TIMEOUT + 4000;
  let lastError = '';
  while (Date.now() < end) {
    await waitForLoad(tabId);
    try {
      const msg: Message = { kind: 'replay-step', step, password, timeout: ACTION_TIMEOUT };
      const res = (await chrome.tabs.sendMessage(tabId, msg, { frameId: 0 })) as ReplayResponse | undefined;
      // Pas de réponse : la page a navigué pendant l'action, qui a donc bien eu lieu.
      return res ?? { ok: true };
    } catch (e) {
      lastError = String((e as Error).message ?? e);
      await ensureInjected(tabId);
      await sleep(250);
    }
  }
  return { ok: false, message: `Page injoignable : ${lastError}` };
}

async function runStep(tabId: number, step: Step, first: boolean, password?: string): Promise<StepResult> {
  if (step.type === 'navigate') {
    if (first || !step.implicit) {
      if (step.key === 'reload') await chrome.tabs.reload(tabId);
      else await chrome.tabs.update(tabId, { url: step.url });
      await sleep(150);
      await waitForLoad(tabId);
      return { status: 'ok' };
    }
    // Navigation provoquée par l'action précédente : on attend simplement le
    // chargement, sans comparer l'URL (elle peut varier selon l'environnement).
    await sleep(150);
    await waitForLoad(tabId);
    return { status: 'ok', message: 'Navigation suivie (URL non comparée)' };
  }
  const res = await sendStep(tabId, step, password);
  return { status: res.ok ? (res.skipped ? 'skipped' : 'ok') : 'fail', message: res.message, checks: res.checks };
}

async function setResult(id: string, r: StepResult, current?: number): Promise<void> {
  await update((s) => {
    if (!s.replay) return;
    s.replay.results[id] = r;
    if (current !== undefined) s.replay.current = current;
  });
}

async function runReplay(tabId: number, password: string | undefined, fromIndex: number): Promise<void> {
  replayAbort = false;
  await update((s) => {
    s.recording = false;
    s.paused = false;
    s.selecting = false;
    s.replay = { running: true, tabId, startedAt: Date.now(), current: fromIndex, results: {} };
  });
  await chrome.tabs.update(tabId, { active: true });
  const { steps, settings } = await readState();
  let failed = false;
  for (let i = fromIndex; i < steps.length; i++) {
    const step = steps[i];
    if (replayAbort || (failed && settings.stopOnFailure)) {
      await setResult(step.id, { status: 'skipped', message: replayAbort ? 'Rejeu arrêté' : 'Non rejouée après un échec' });
      continue;
    }
    await setResult(step.id, { status: 'running' }, i);
    let res: StepResult;
    try {
      res = await runStep(tabId, step, i === fromIndex, password);
    } catch (e) {
      res = { status: 'fail', message: String((e as Error).message ?? e) };
    }
    await setResult(step.id, res);
    if (res.status === 'fail' && step.type !== 'snapshot') failed = true;
    await sleep(settings.replayDelay);
  }
  await update((s) => {
    if (!s.replay) return;
    s.replay.running = false;
    s.replay.finishedAt = Date.now();
    s.replay.stopped = replayAbort;
  });
}

// --- Navigation de l'onglet enregistré ---
const EXPLICIT = new Set(['typed', 'auto_bookmark', 'generated', 'keyword', 'keyword_generated', 'start_page']);

async function onNavigation(tabId: number, frameId: number, url: string, transition: string | undefined, spa: boolean) {
  if (frameId !== 0 || !/^(https?|file):/.test(url)) return;
  const s = await readState();
  if (!s.recording || s.paused || s.tabId !== tabId || !s.settings.recordNavigation) return;
  const tab = await chrome.tabs.get(tabId).catch(() => undefined);
  await update((st) =>
    pushStep(st, {
      id: uid(),
      type: 'navigate',
      timestamp: Date.now(),
      url,
      title: tab?.title,
      implicit: transition !== 'reload' && (spa || !EXPLICIT.has(transition ?? '')),
      key: transition === 'reload' ? 'reload' : undefined,
    }),
  );
}

chrome.webNavigation.onCommitted.addListener((d) => void onNavigation(d.tabId, d.frameId, d.url, d.transitionType, false));
chrome.webNavigation.onHistoryStateUpdated.addListener((d) => void onNavigation(d.tabId, d.frameId, d.url, d.transitionType, true));
chrome.webNavigation.onReferenceFragmentUpdated.addListener((d) => void onNavigation(d.tabId, d.frameId, d.url, d.transitionType, true));

chrome.tabs.onRemoved.addListener((tabId) => {
  void readState().then((s) => {
    if (s.tabId === tabId && s.recording) void update((st) => void (st.recording = false));
  });
});

// --- Raccourci clavier ---
chrome.commands.onCommand.addListener((command) => {
  if (command === 'select-region') void startSelection(undefined);
});

// --- Ouverture du panneau latéral au clic sur l'icône ---
const setup = () => {
  void chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true });
  void update((s) => {
    s.selecting = false;
    if (s.replay) s.replay.running = false;
  });
};
chrome.runtime.onInstalled.addListener(setup);
chrome.runtime.onStartup.addListener(setup);
