/**
 * Rejeu d'une étape dans la page : retrouve l'élément ciblé, simule l'action
 * (événements compatibles Angular / Angular Material) ou vérifie une zone.
 */
import type { ElementTarget, EntryCheck, ReplayResponse, SnapshotEntry, Step } from '../shared/types';
import { accessibleName, associatedLabel, clean, controlValue, fieldLabel, implicitRole, isVisible, visibleText } from './dom';

const ROLE_SEL: Record<string, string> = {
  button: 'button, [role=button], input[type=button], input[type=submit], input[type=reset], input[type=image]',
  link: 'a[href], [role=link]',
  checkbox: 'input[type=checkbox], [role=checkbox]',
  radio: 'input[type=radio], [role=radio]',
  switch: '[role=switch]',
  tab: '[role=tab]',
  option: 'option, [role=option], mat-option',
  menuitem: '[role=menuitem]',
  menuitemcheckbox: '[role=menuitemcheckbox]',
  menuitemradio: '[role=menuitemradio]',
  heading: 'h1,h2,h3,h4,h5,h6,[role=heading]',
  combobox: 'select, [role=combobox], input[list]',
  textbox: 'input, textarea, [role=textbox]',
  searchbox: 'input[type=search], [role=searchbox]',
  slider: 'input[type=range], [role=slider]',
  spinbutton: 'input[type=number], [role=spinbutton]',
  treeitem: '[role=treeitem]',
  gridcell: '[role=gridcell], td',
  img: 'img, [role=img]',
};

const FIELDS =
  'input:not([type=hidden]), select, textarea, [role=combobox], [role=textbox], [role=checkbox], [role=switch], [role=radio], [role=slider], [role=spinbutton]';

const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));

function usable(el: Element): boolean {
  return isVisible(el) || el.matches('input[type=checkbox], input[type=radio]');
}

function queryAll(sel: string): Element[] {
  try {
    return Array.from(document.querySelectorAll(sel));
  } catch {
    return [];
  }
}

/** Résout un localisateur dans le document courant (null si absent ou ambigu). */
function resolveOnce(t: ElementTarget): Element | null {
  const l = t.locator;
  let found: Element[] = [];
  switch (l.by) {
    case 'testid':
      found = queryAll(`[${l.attr}="${CSS.escape(l.value)}"]`);
      break;
    case 'label':
      found = queryAll(FIELDS).filter((e) => associatedLabel(e) === l.value);
      break;
    case 'role':
      found = queryAll(ROLE_SEL[l.role] ?? `[role="${l.role}"]`).filter((e) => implicitRole(e) === l.role && accessibleName(e) === l.name);
      break;
    case 'placeholder':
      found = queryAll(`[placeholder="${CSS.escape(l.value)}"]`);
      break;
    case 'text':
      found = queryAll('body *').filter((e) => visibleText(e) === l.value && !Array.from(e.children).some((c) => visibleText(c) === l.value));
      break;
    case 'css':
      break;
  }
  const visible = found.filter(usable);
  if (visible.length === 1) return visible[0];
  // Repli sur le sélecteur CSS enregistré.
  const css = queryAll(t.css).filter(usable);
  if (css.length >= 1) return css[0];
  return visible[0] ?? found[0] ?? null;
}

async function resolve(t: ElementTarget, timeout: number): Promise<Element> {
  const end = Date.now() + timeout;
  for (;;) {
    const el = resolveOnce(t);
    if (el) return el;
    if (Date.now() > end) throw new Error(`Élément introuvable : ${describe(t)}`);
    await sleep(150);
  }
}

function describe(t: ElementTarget): string {
  const l = t.locator;
  if (l.by === 'role') return `${l.role} « ${l.name} »`;
  if (l.by === 'css') return l.value;
  return `${l.by} « ${l.value} »`;
}

// --- Mise en évidence visuelle de l'élément rejoué ---
function flash(el: Element, ok = true): void {
  const r = el.getBoundingClientRect();
  const d = document.createElement('div');
  d.style.cssText = `position:fixed;z-index:2147483646;pointer-events:none;left:${r.left - 3}px;top:${r.top - 3}px;width:${r.width + 6}px;height:${r.height + 6}px;border:2px solid ${ok ? '#43a047' : '#e53935'};border-radius:4px;background:${ok ? 'rgba(67,160,71,.12)' : 'rgba(229,57,53,.12)'};transition:opacity .4s`;
  (document.body || document.documentElement).appendChild(d);
  setTimeout(() => (d.style.opacity = '0'), 500);
  setTimeout(() => d.remove(), 950);
}

// --- Simulation d'événements ---
function mouse(el: Element, type: string, detail = 1): void {
  const r = el.getBoundingClientRect();
  const init: MouseEventInit = {
    bubbles: true,
    cancelable: true,
    composed: true,
    view: window,
    detail,
    clientX: r.left + r.width / 2,
    clientY: r.top + r.height / 2,
    button: 0,
    buttons: type.endsWith('down') ? 1 : 0,
  };
  const Ctor = type.startsWith('pointer') ? PointerEvent : MouseEvent;
  el.dispatchEvent(new Ctor(type, { ...init, ...(Ctor === PointerEvent ? { pointerId: 1, pointerType: 'mouse', isPrimary: true } : {}) }));
}

function click(target: Element, detail = 1): void {
  target.scrollIntoView({ block: 'center', inline: 'center' });
  // Comme un vrai clic : vise l'élément réellement affiché au centre (ex. le
  // déclencheur interne d'un mat-select), s'il appartient à la cible.
  const r = target.getBoundingClientRect();
  const hit = document.elementFromPoint(r.left + r.width / 2, r.top + r.height / 2);
  const el = hit && target.contains(hit) ? hit : target;
  mouse(el, 'pointerover');
  mouse(el, 'mouseover');
  mouse(el, 'pointerdown', detail);
  mouse(el, 'mousedown', detail);
  if (el instanceof HTMLElement && el.tabIndex >= 0) el.focus({ preventScroll: true });
  mouse(el, 'pointerup', detail);
  mouse(el, 'mouseup', detail);
  // HTMLElement.click() déclenche les comportements natifs (liens, cases, submit).
  if (el instanceof HTMLElement) el.click();
  else mouse(el, 'click', detail);
}

/** Affecte une valeur comme le ferait l'utilisateur (compatible ngModel / FormControl). */
function setValue(el: Element, value: string): void {
  if (el instanceof HTMLElement) el.focus({ preventScroll: true });
  if (el instanceof HTMLInputElement || el instanceof HTMLTextAreaElement) {
    const proto = el instanceof HTMLInputElement ? HTMLInputElement.prototype : HTMLTextAreaElement.prototype;
    Object.getOwnPropertyDescriptor(proto, 'value')!.set!.call(el, value);
  } else if (el instanceof HTMLSelectElement) {
    const values = value.split(',');
    Array.from(el.options).forEach((o) => (o.selected = values.includes(o.value)));
  } else if ((el as HTMLElement).isContentEditable) {
    (el as HTMLElement).innerText = value;
  }
  el.dispatchEvent(new InputEvent('input', { bubbles: true, composed: true, inputType: 'insertText', data: value }));
  el.dispatchEvent(new Event('change', { bubbles: true }));
}

function key(el: Element, combo: string): void {
  const parts = combo.split('+');
  const k = parts[parts.length - 1];
  const init: KeyboardEventInit = {
    key: k,
    code: k.length === 1 ? `Key${k.toUpperCase()}` : k,
    bubbles: true,
    cancelable: true,
    composed: true,
    ctrlKey: parts.includes('Control'),
    metaKey: parts.includes('Meta'),
    altKey: parts.includes('Alt'),
    shiftKey: parts.includes('Shift'),
  };
  const down = el.dispatchEvent(new KeyboardEvent('keydown', init));
  if (k === 'Enter') el.dispatchEvent(new KeyboardEvent('keypress', init));
  el.dispatchEvent(new KeyboardEvent('keyup', init));
  if (!down) return; // l'application a géré la touche
  // Comportements natifs que des événements synthétiques ne déclenchent pas.
  if (k === 'Enter' && el instanceof HTMLInputElement && el.form) el.form.requestSubmit();
  else if (k === 'Enter' && el instanceof HTMLElement && el.matches('a[href], button, [role=button], [role=option], [role=menuitem]')) el.click();
  else if (k === 'Tab') moveFocus(el, init.shiftKey ? -1 : 1);
}

function moveFocus(from: Element, dir: number): void {
  const all = queryAll('a[href], button, input, select, textarea, [tabindex]:not([tabindex="-1"]), [contenteditable=true]').filter(
    (e) => isVisible(e) && !(e as HTMLInputElement).disabled,
  ) as HTMLElement[];
  const i = all.indexOf(from as HTMLElement);
  all[(i + dir + all.length) % all.length]?.focus();
}

// --- Vérification d'une zone ---
function norm(v: string): string {
  return clean(v, 10_000);
}

function actualOf(e: SnapshotEntry, el: Element): string {
  switch (e.kind) {
    case 'radio':
      return controlValue(el).raw === true ? fieldLabel(el) : '(non coché)';
    case 'pair':
    case 'table':
    case 'text':
      return visibleText(el, 10_000);
    default:
      return controlValue(el).value;
  }
}

async function verify(step: Step, timeout: number): Promise<ReplayResponse> {
  const checks: EntryCheck[] = [];
  for (const e of step.snapshot!.entries) {
    if (e.value === '••••••') {
      checks.push({ entryId: e.id, ok: true, actual: '(mot de passe non vérifié)' });
      continue;
    }
    const expected = norm(e.kind === 'pair' && typeof e.raw === 'string' && e.raw ? e.raw : e.value);
    // Laisse à l'application le temps d'afficher la valeur attendue.
    const end = Date.now() + timeout;
    let actual = '';
    let el: Element | null = null;
    for (;;) {
      el = resolveOnce(e.target);
      actual = el ? norm(actualOf(e, el)) : '(élément introuvable)';
      if ((el && actual === expected) || Date.now() > end) break;
      await sleep(150);
    }
    const ok = !!el && actual === expected;
    if (el) flash(el, ok);
    checks.push({ entryId: e.id, ok, actual });
  }
  const failed = checks.filter((c) => !c.ok).length;
  return { ok: failed === 0, checks, message: failed ? `${failed} valeur(s) différente(s)` : `${checks.length} valeur(s) vérifiée(s)` };
}

// --- Point d'entrée ---
export async function replayStep(step: Step, password: string | undefined, timeout: number): Promise<ReplayResponse> {
  if (step.type === 'snapshot') return verify(step, timeout);
  if (step.type === 'submit') return { ok: true, skipped: true, message: 'Soumission déclenchée par l’étape précédente' };
  if (!step.target) {
    if (step.type === 'keypress') {
      key(document.activeElement ?? document.body, step.key ?? '');
      return { ok: true };
    }
    return { ok: true, skipped: true };
  }
  if (step.target.frameUrl) return { ok: true, skipped: true, message: 'Étape dans une iframe : non rejouée' };

  const el = await resolve(step.target, timeout);
  flash(el);
  switch (step.type) {
    case 'click':
      click(el);
      break;
    case 'dblclick':
      click(el, 1);
      click(el, 2);
      mouse(el, 'dblclick', 2);
      break;
    case 'input':
      if (step.key === 'file') return { ok: true, skipped: true, message: 'Sélection de fichier : non rejouable dans le navigateur' };
      if (step.masked) {
        if (!password) return { ok: true, skipped: true, message: 'Mot de passe masqué : renseignez-le dans le panneau pour le rejouer' };
        setValue(el, password);
      } else setValue(el, step.value ?? '');
      break;
    case 'select':
      setValue(el, step.value ?? '');
      break;
    case 'check': {
      const current = controlValue(el).raw === true;
      if (current !== !!step.checked) click(el);
      break;
    }
    case 'keypress':
      key(el, step.key ?? '');
      break;
  }
  return { ok: true };
}
