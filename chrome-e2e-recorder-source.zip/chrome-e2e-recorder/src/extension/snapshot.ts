/**
 * Extraction de tous les libellés et valeurs présents dans une zone de la page.
 */
import type { Rect, SnapshotEntry, SnapshotKind } from '../shared/types';
import { uid } from '../shared/types';
import { clean, controlValue, describeTarget, fieldLabel, implicitRole, isVisible, visibleText } from './dom';

const CONTROL_SEL = [
  'input:not([type=hidden]):not([type=button]):not([type=submit]):not([type=reset]):not([type=image])',
  'textarea',
  'select',
  '[contenteditable=""]',
  '[contenteditable=true]',
  '[role=combobox]',
  '[role=checkbox]',
  '[role=switch]',
  '[role=radio]',
  '[role=slider]',
  '[role=spinbutton]',
  '[role=textbox]',
  '[role=progressbar]',
].join(',');

const SKIP_TEXT = 'script, style, noscript, template, svg, mat-icon, .material-icons, .material-symbols-outlined, [aria-hidden=true]';

function intersects(r: DOMRect, area: Rect, minRatio = 0.5): boolean {
  const ix = Math.max(0, Math.min(r.right, area.x + area.width) - Math.max(r.left, area.x));
  const iy = Math.max(0, Math.min(r.bottom, area.y + area.height) - Math.max(r.top, area.y));
  const surface = r.width * r.height;
  if (surface === 0) return false;
  return (ix * iy) / surface >= minRatio;
}

function inArea(el: Element, area: Rect): boolean {
  const r = el.getBoundingClientRect();
  if (r.width === 0 && r.height === 0) {
    // Input natif masqué (Material) : on se base sur le parent visible.
    const p = el.parentElement;
    return !!p && intersects(p.getBoundingClientRect(), area);
  }
  return intersects(r, area);
}

/** Tous les éléments (y compris dans les shadow roots ouvertes) d'une racine. */
function allElements(root: ParentNode, sel: string): Element[] {
  const out: Element[] = Array.from(root.querySelectorAll(sel));
  root.querySelectorAll('*').forEach((e) => {
    if (e.shadowRoot) out.push(...allElements(e.shadowRoot, sel));
  });
  return out;
}

function kindOf(el: Element): SnapshotKind {
  if (el instanceof HTMLTextAreaElement) return 'textarea';
  if (el instanceof HTMLSelectElement) return 'select';
  if (el instanceof HTMLInputElement) {
    if (el.type === 'checkbox') return 'checkbox';
    if (el.type === 'radio') return 'radio';
    if (el.type === 'range') return 'slider';
    return 'input';
  }
  const role = implicitRole(el);
  if (role === 'checkbox' || role === 'switch') return 'checkbox';
  if (role === 'radio') return 'radio';
  if (role === 'combobox') return 'combobox';
  if (role === 'slider' || role === 'spinbutton' || role === 'progressbar') return 'slider';
  if ((el as HTMLElement).isContentEditable) return 'editable';
  return 'input';
}

export function extractEntries(area: Rect, scope: Element = document.body, maskPasswords = true): SnapshotEntry[] {
  const entries: SnapshotEntry[] = [];
  const consumed = new Set<Element>();
  const add = (kind: SnapshotKind, label: string, value: string, el: Element, raw?: string | boolean) => {
    entries.push({ id: uid(), kind, label: clean(label, 120), value: clean(value, 500), raw, target: describeTarget(el) });
  };

  // 1. Contrôles de formulaire.
  const controls = allElements(scope, CONTROL_SEL).filter((el) => inArea(el, area) && (isVisible(el) || el.matches('input[type=checkbox],input[type=radio]')));
  const radioGroups = new Map<string | Element, Element[]>();
  for (const el of controls) {
    // Un composant ARIA qui contient un contrôle natif : on garde le natif.
    if (!el.matches('input,select,textarea') && el.querySelector('input:not([type=hidden]),select,textarea')) continue;
    // Un contrôle natif à l'intérieur d'un combobox Material déjà traité.
    if (el.closest('[contenteditable=true]') && el.closest('[contenteditable=true]') !== el) continue;
    const kind = kindOf(el);
    if (kind === 'radio') {
      const group =
        el.closest('[role=radiogroup], mat-radio-group, fieldset') ||
        (el.getAttribute('name') ? null : el.parentElement);
      const key: string | Element = el.getAttribute('name') || group || el;
      if (!radioGroups.has(key)) radioGroups.set(key, []);
      radioGroups.get(key)!.push(el);
      continue;
    }
    const label = fieldLabel(el);
    let { value, raw } = controlValue(el);
    if (maskPasswords && el instanceof HTMLInputElement && el.type === 'password') {
      value = value ? '••••••' : '';
      raw = undefined;
    }
    add(kind, label, value, el, raw);
    consumed.add(el);
    consumeLabels(el, consumed);
    const ff = el.closest('mat-form-field, .mat-mdc-form-field, label');
    if (ff) consumed.add(ff);
  }

  // Groupes de boutons radio : un seul couple libellé du groupe / option choisie.
  for (const radios of radioGroups.values()) {
    const first = radios[0];
    const group = first.closest('[role=radiogroup], mat-radio-group, fieldset');
    let groupLabel = '';
    if (group) {
      const legend = group.querySelector(':scope > legend');
      groupLabel = legend
        ? visibleText(legend)
        : group.getAttribute('aria-label') ||
          (group.getAttribute('aria-labelledby') && visibleText(document.getElementById(group.getAttribute('aria-labelledby')!) ?? group)) ||
          '';
      if (!groupLabel) {
        const prev = group.previousElementSibling;
        if (prev) groupLabel = visibleText(prev, 80);
      }
    }
    if (!groupLabel) groupLabel = first.getAttribute('name') || 'Choix';
    const checked = radios.find((r) => controlValue(r).raw === true);
    const value = checked ? fieldLabel(checked) : '';
    entries.push({
      id: uid(),
      kind: 'radio',
      label: clean(groupLabel, 120),
      value,
      raw: value,
      target: describeTarget(checked ?? group ?? first),
    });
    radios.forEach((r) => {
      consumed.add(r);
      consumeLabels(r, consumed);
    });
    if (group) consumed.add(group);
  }

  // 2. Listes de définitions <dl><dt>Libellé</dt><dd>Valeur</dd></dl>.
  for (const dt of allElements(scope, 'dt')) {
    if (!inArea(dt, area) || !isVisible(dt)) continue;
    let dd = dt.nextElementSibling;
    const values: string[] = [];
    let firstDd: Element | null = null;
    while (dd && dd.tagName === 'DD') {
      firstDd ??= dd;
      values.push(visibleText(dd));
      consumed.add(dd);
      dd = dd.nextElementSibling;
    }
    if (firstDd) {
      add('pair', visibleText(dt), values.join(', '), firstDd);
      consumed.add(dt);
    }
  }

  // 3. Tableaux : en-tête de colonne / en-tête de ligne -> valeur de cellule.
  for (const table of allElements(scope, 'table, [role=table], [role=grid], mat-table')) {
    if (!isVisible(table) || !intersects(table.getBoundingClientRect(), area, 0.01)) continue;
    const headerCells = Array.from(table.querySelectorAll('thead th, [role=columnheader], mat-header-cell, th[mat-header-cell]'));
    const headers = headerCells.map((h) => visibleText(h, 80));
    headerCells.forEach((h) => consumed.add(h));
    const rows = Array.from(table.querySelectorAll('tbody tr, [role=row], mat-row, tr[mat-row]')).filter(
      (r) => !r.querySelector('th[scope=col], [role=columnheader], mat-header-cell') && inArea(r, area),
    );
    rows.forEach((row, ri) => {
      const cells = Array.from(row.children).filter((c) => c.matches('td, th, [role=cell], [role=gridcell], [role=rowheader], mat-cell'));
      const rowHeader = cells.find((c) => c.matches('th, [role=rowheader]'));
      const rowName = rowHeader ? visibleText(rowHeader, 60) : `Ligne ${ri + 1}`;
      cells.forEach((cell, ci) => {
        if (cell === rowHeader) {
          consumed.add(cell);
          return;
        }
        if (consumed.has(cell) || cell.querySelector(CONTROL_SEL)) {
          consumed.add(cell);
          return;
        }
        const value = visibleText(cell);
        consumed.add(cell);
        if (!value) return;
        const col = headers[ci] || (headers.length === 0 && rowHeader ? '' : `Colonne ${ci + 1}`);
        const label = rowHeader && headers.length === 0 ? rowName : col ? `${rowName} › ${col}` : rowName;
        add('table', label, value, cell);
      });
    });
    consumed.add(table);
  }

  // 4. Couples libellé / valeur dans le texte : « Nom : Dupont », <b>Nom</b><span>Dupont</span>…
  const leafs = allElements(scope, '*').filter((el) => {
    if (consumed.has(el) || el.closest(SKIP_TEXT) || !isVisible(el)) return false;
    if (el.closest('table, [role=table], [role=grid], mat-table, dl, select, textarea')) return false;
    if (Array.from(consumed).some((c) => c !== el && c.contains(el))) return false;
    // Feuille textuelle : a du texte direct et aucun enfant élément porteur de texte.
    const hasOwnText = Array.from(el.childNodes).some((n) => n.nodeType === 3 && n.textContent!.trim());
    return hasOwnText && inArea(el, area);
  });

  const used = new Set<Element>();
  for (const el of leafs) {
    if (used.has(el)) continue;
    const text = visibleText(el, 300);
    if (!text) continue;
    // Libellé suivi d'une valeur dans l'élément frère.
    const looksLabel = /:\s*$/.test(text) || el.matches('label, th, dt, strong, b, .label, [class*="label"], [class*="title"], mat-label');
    const next = el.nextElementSibling;
    if (looksLabel && next && !used.has(next) && !next.matches('input,select,textarea,button') && text.length <= 60) {
      const v = visibleText(next, 300);
      if (v && !next.querySelector(CONTROL_SEL)) {
        add('pair', text.replace(/\s*:\s*$/, ''), v, next);
        used.add(el);
        used.add(next);
        next.querySelectorAll('*').forEach((c) => used.add(c));
        continue;
      }
    }
    // « Libellé : valeur » dans un même élément.
    const m = text.match(/^([^:]{1,50}?)\s*:\s+(.{1,300})$/);
    if (m && !/^https?$/i.test(m[1])) {
      add('pair', m[1], m[2], el, text);
      used.add(el);
      continue;
    }
    // Sinon : texte libre, libellé = titre ou nature de l'élément.
    add('text', textLabel(el), text, el);
    used.add(el);
    el.querySelectorAll('*').forEach((c) => used.add(c));
  }

  return entries;
}

/** Marque comme traités les éléments qui servent de libellé à un contrôle. */
function consumeLabels(el: Element, consumed: Set<Element>): void {
  const labels = (el as HTMLInputElement).labels;
  if (labels) Array.from(labels).forEach((l) => consumed.add(l));
  const lb = el.getAttribute('aria-labelledby');
  if (lb) lb.split(/\s+/).forEach((id) => {
    const n = document.getElementById(id);
    if (n) consumed.add(n);
  });
  const label = fieldLabel(el);
  const prev = el.previousElementSibling;
  if (prev && visibleText(prev, 80).replace(/\s*:\s*$/, '') === label) consumed.add(prev);
  // Texte libre du composant hôte (ex. <mat-slide-toggle><button/> Newsletter</mat-slide-toggle>).
  const host = el.parentElement;
  if (host && !host.matches('section, form, fieldset, body, [role=radiogroup], [role=group]') && visibleText(host, 80) === label) consumed.add(host);
  const cell = el.closest('td')?.previousElementSibling;
  if (cell && visibleText(cell, 80).replace(/\s*:\s*$/, '') === label) consumed.add(cell);
}

function textLabel(el: Element): string {
  const role = implicitRole(el);
  if (role === 'heading' || el.closest('mat-card-title, mat-dialog-title, [mat-dialog-title], mat-toolbar, legend')) return 'Titre';
  if (role === 'button' || el.closest('button, [role=button]')) return 'Bouton';
  if (role === 'link' || el.closest('a[href]')) return 'Lien';
  if (el.closest('[role=alert], mat-error, .mat-mdc-form-field-error, .error, .invalid-feedback')) return 'Erreur';
  if (el.closest('mat-hint, .mat-mdc-form-field-hint')) return 'Aide';
  if (el.closest('[role=status], snack-bar-container, .mat-mdc-snack-bar-container, .toast')) return 'Message';
  if (el.closest('mat-chip, mat-chip-option, .badge, .chip')) return 'Étiquette';
  if (el.closest('li, [role=listitem], mat-list-item')) return 'Élément de liste';
  const section = el.closest('section, article, mat-card, fieldset, [role=region], form');
  const heading = section?.querySelector('h1,h2,h3,h4,h5,h6,legend,mat-card-title,[role=heading]');
  if (heading && heading !== el && !heading.contains(el)) return `Texte (${visibleText(heading, 40)})`;
  return 'Texte';
}
