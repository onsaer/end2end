/**
 * Utilitaires DOM : sélecteurs robustes, libellés accessibles, valeurs,
 * avec une attention particulière aux applications Angular / Angular Material.
 */
import type { ElementTarget, Locator } from '../shared/types';

const TEST_ATTRS = ['data-testid', 'data-test-id', 'data-test', 'data-cy', 'data-qa', 'data-e2e', 'data-automation-id'];

/** Identifiants générés dynamiquement (Angular Material, CDK, React, hash…). */
const DYNAMIC_ID = /^(mat-|cdk-|ng-|mdc-|mat-mdc-|_ng|ui-id-|react-|:r)|[0-9a-f]{8,}|\d{3,}|^\d/i;
/** Classes techniques à ne jamais utiliser dans un sélecteur. */
const NOISY_CLASS =
  /^(ng-|cdk-|mat-mdc-|mdc-|mat-focus|mat-ripple|mat-active|is-|has-|active|focus|hover|selected|disabled|open|show|collapsed|ripple)|\d{3,}|_[a-z0-9]{5,}$/i;

export function cssEscape(v: string): string {
  return CSS.escape(v);
}

function attrSel(tag: string, name: string, value: string): string {
  return `${tag}[${name}="${value.replace(/\\/g, '\\\\').replace(/"/g, '\\"')}"]`;
}

function rootOf(el: Element): Document | ShadowRoot {
  const r = el.getRootNode();
  return r instanceof ShadowRoot ? r : document;
}

function isUnique(sel: string, el: Element): boolean {
  try {
    const found = rootOf(el).querySelectorAll(sel);
    return found.length === 1 && found[0] === el;
  } catch {
    return false;
  }
}

function stableId(el: Element): string | null {
  const id = el.id;
  return id && !DYNAMIC_ID.test(id) ? id : null;
}

/** Attributs « sémantiques » pour un seul élément, du plus au moins fiable. */
function ownCandidates(el: Element): string[] {
  const tag = el.tagName.toLowerCase();
  const out: string[] = [];
  for (const a of TEST_ATTRS) {
    const v = el.getAttribute(a);
    if (v) out.push(attrSel('', a, v));
  }
  const id = stableId(el);
  if (id) out.push('#' + cssEscape(id));
  for (const a of ['formcontrolname', 'name', 'ng-reflect-name', 'aria-label', 'placeholder', 'title', 'alt', 'for']) {
    const v = el.getAttribute(a);
    if (v && v.length < 80) out.push(attrSel(tag, a, v));
  }
  if (tag === 'a') {
    const href = el.getAttribute('href') || el.getAttribute('routerlink');
    if (href && !href.startsWith('javascript:') && href.length < 120) out.push(attrSel('a', el.hasAttribute('href') ? 'href' : 'routerlink', href));
  }
  if (tag === 'input' || tag === 'button') {
    const type = el.getAttribute('type');
    if (type) out.push(attrSel(tag, 'type', type));
  }
  return out;
}

function segment(el: Element): string {
  const tag = el.tagName.toLowerCase();
  const id = stableId(el);
  if (id) return '#' + cssEscape(id);
  for (const a of TEST_ATTRS) {
    const v = el.getAttribute(a);
    if (v) return attrSel('', a, v);
  }
  const fcn = el.getAttribute('formcontrolname') || el.getAttribute('formgroupname');
  if (fcn) return attrSel(tag, el.hasAttribute('formcontrolname') ? 'formcontrolname' : 'formgroupname', fcn);
  const classes = Array.from(el.classList).filter((c) => !NOISY_CLASS.test(c)).slice(0, 2);
  let seg = tag + classes.map((c) => '.' + cssEscape(c)).join('');
  const parent = el.parentElement;
  if (parent) {
    const same = Array.from(parent.children).filter((c) => c.tagName === el.tagName);
    if (same.length > 1) seg = `${tag}:nth-of-type(${same.indexOf(el) + 1})`;
  }
  return seg;
}

/** Sélecteur CSS unique, le plus court et le plus stable possible. */
export function cssSelector(el: Element): string {
  for (const c of ownCandidates(el)) if (isUnique(c, el)) return c;

  // Chemin ascendant : on s'arrête dès que le sélecteur devient unique.
  const parts: string[] = [];
  let cur: Element | null = el;
  let depth = 0;
  while (cur && cur.nodeType === 1 && depth < 12) {
    parts.unshift(segment(cur));
    const sel = parts.join(' > ');
    if (isUnique(sel, el)) return sel;
    // Un ancêtre avec un attribut sémantique sert d'ancre avec un combinateur descendant.
    if (depth === 0) {
      for (const c of ownCandidates(el)) {
        let anc: Element | null = el.parentElement;
        while (anc) {
          const a = ancestorAnchor(anc);
          if (a && isUnique(`${a} ${c}`, el)) return `${a} ${c}`;
          anc = anc.parentElement;
        }
      }
    }
    cur = cur.parentElement;
    depth++;
  }
  return parts.join(' > ');
}

function ancestorAnchor(el: Element): string | null {
  for (const a of TEST_ATTRS) {
    const v = el.getAttribute(a);
    if (v) return attrSel('', a, v);
  }
  const id = stableId(el);
  if (id) return '#' + cssEscape(id);
  const fg = el.getAttribute('formgroupname') || el.getAttribute('formarrayname');
  if (fg) return attrSel(el.tagName.toLowerCase(), el.hasAttribute('formgroupname') ? 'formgroupname' : 'formarrayname', fg);
  return null;
}

export function clean(text: string | null | undefined, max = 200): string {
  const t = (text || '').replace(/\s+/g, ' ').trim();
  return t.length > max ? t.slice(0, max - 1) + '…' : t;
}

/** Texte visible d'un élément sans le contenu des contrôles imbriqués. */
export function visibleText(el: Element, max = 200): string {
  const html = el as HTMLElement;
  let t = html.innerText ?? el.textContent ?? '';
  if (el.querySelector('input,select,textarea')) {
    const clone = el.cloneNode(true) as HTMLElement;
    clone.querySelectorAll('input,select,textarea,script,style,mat-icon,.material-icons').forEach((n) => n.remove());
    t = clone.textContent || '';
  }
  return clean(t, max);
}

function textOfIds(ids: string, doc: Document | ShadowRoot): string {
  return clean(
    ids
      .split(/\s+/)
      .map((id) => doc.getElementById?.(id) ?? (doc as Document).querySelector?.('#' + cssEscape(id)))
      .filter(Boolean)
      .map((n) => visibleText(n as Element))
      .join(' '),
  );
}

export function implicitRole(el: Element): string {
  const explicit = el.getAttribute('role');
  if (explicit) return explicit.split(/\s+/)[0];
  const tag = el.tagName.toLowerCase();
  const type = (el.getAttribute('type') || 'text').toLowerCase();
  switch (tag) {
    case 'button':
      return 'button';
    case 'a':
      return el.hasAttribute('href') ? 'link' : '';
    case 'select':
      return (el as HTMLSelectElement).multiple ? 'listbox' : 'combobox';
    case 'textarea':
      return 'textbox';
    case 'option':
      return 'option';
    case 'img':
      return 'img';
    case 'h1':
    case 'h2':
    case 'h3':
    case 'h4':
    case 'h5':
    case 'h6':
      return 'heading';
    case 'input':
      if (['button', 'submit', 'reset', 'image'].includes(type)) return 'button';
      if (type === 'checkbox') return 'checkbox';
      if (type === 'radio') return 'radio';
      if (type === 'range') return 'slider';
      if (type === 'number') return 'spinbutton';
      if (type === 'search') return 'searchbox';
      return 'textbox';
  }
  return '';
}

/** Libellé d'un champ de formulaire (label, aria, mat-label, placeholder…). */
export function fieldLabel(el: Element): string {
  const root = rootOf(el);
  const lb = el.getAttribute('aria-labelledby');
  if (lb) {
    const t = textOfIds(lb, root);
    if (t) return t;
  }
  const al = el.getAttribute('aria-label');
  if (al) return clean(al);

  const labels = (el as HTMLInputElement).labels;
  if (labels && labels.length) {
    const t = clean(Array.from(labels).map((l) => visibleText(l)).join(' '));
    if (t) return t.replace(/\s*\*$/, '');
  }
  // Angular Material : <mat-form-field><mat-label>…</mat-label>…</mat-form-field>
  const ff = el.closest('mat-form-field, .mat-mdc-form-field, .mat-form-field');
  if (ff) {
    const ml = ff.querySelector('mat-label, .mat-mdc-floating-label, .mdc-floating-label, label');
    const t = ml && visibleText(ml).replace(/\s*\*$/, '');
    if (t) return t;
  }
  const wrap = el.closest('label');
  if (wrap) {
    const t = visibleText(wrap);
    if (t) return t;
  }
  const ph = el.getAttribute('placeholder');
  if (ph) return clean(ph);
  const title = el.getAttribute('title');
  if (title) return clean(title);

  // Libellé positionné juste avant : <span>Nom</span><input> ou cellule précédente.
  const prev = el.previousElementSibling;
  if (prev && !prev.matches('input,select,textarea,button')) {
    const t = visibleText(prev, 80);
    if (t && t.length <= 60) return t.replace(/\s*:\s*$/, '');
  }
  const cell = el.closest('td');
  if (cell) {
    const prevCell = cell.previousElementSibling;
    const t = prevCell && visibleText(prevCell, 80);
    if (t) return t.replace(/\s*:\s*$/, '');
  }
  const name = el.getAttribute('formcontrolname') || el.getAttribute('name') || el.id;
  return name ? humanize(name) : '';
}

export function humanize(name: string): string {
  return name
    .replace(/[_\-.]+/g, ' ')
    .replace(/([a-z])([A-Z])/g, '$1 $2')
    .replace(/^\w/, (c) => c.toUpperCase());
}

/** Nom accessible approximatif (utilisé pour getByRole). */
export function accessibleName(el: Element): string {
  const role = implicitRole(el);
  if (['textbox', 'searchbox', 'combobox', 'checkbox', 'radio', 'slider', 'spinbutton', 'switch', 'listbox'].includes(role)) {
    return fieldLabel(el);
  }
  const root = rootOf(el);
  const lb = el.getAttribute('aria-labelledby');
  if (lb) {
    const t = textOfIds(lb, root);
    if (t) return t;
  }
  const al = el.getAttribute('aria-label');
  if (al) return clean(al);
  if (el instanceof HTMLInputElement) return clean(el.value || el.getAttribute('alt') || '');
  if (el instanceof HTMLImageElement) return clean(el.alt);
  const t = visibleText(el, 120);
  if (t) return t;
  return clean(el.getAttribute('title') || '');
}

/** Élément interactif le plus pertinent autour de la cible brute d'un clic. */
export function interactiveAncestor(el: Element): Element {
  const hit = el.closest(
    'button, a[href], input, select, textarea, label, summary, option, [role=button], [role=link], [role=menuitem], [role=menuitemcheckbox], [role=menuitemradio], [role=option], [role=tab], [role=checkbox], [role=switch], [role=radio], [role=combobox], [role=treeitem], [role=gridcell], [contenteditable=""], [contenteditable=true], mat-option, mat-select, mat-checkbox, mat-radio-button, mat-slide-toggle, mat-chip, mat-chip-option, mat-list-option, mat-tab, [mat-tab-link], [routerlink], [ng-reflect-router-link], [onclick], [tabindex]',
  );
  return hit && hit !== document.body ? hit : el;
}

function countByRole(role: string, name: string, el: Element): number {
  const root = rootOf(el);
  const sels: Record<string, string> = {
    button: 'button, [role=button], input[type=button], input[type=submit], input[type=reset]',
    link: 'a[href], [role=link]',
    checkbox: 'input[type=checkbox], [role=checkbox]',
    radio: 'input[type=radio], [role=radio]',
    tab: '[role=tab]',
    option: 'option, [role=option], mat-option',
    menuitem: '[role=menuitem]',
    heading: 'h1,h2,h3,h4,h5,h6,[role=heading]',
    switch: '[role=switch]',
    combobox: 'select, [role=combobox]',
    textbox: 'input, textarea, [role=textbox]',
  };
  const s = sels[role];
  if (!s) return 99;
  let n = 0;
  root.querySelectorAll(s).forEach((c) => {
    if (implicitRole(c) === role && accessibleName(c) === name && isVisible(c)) n++;
  });
  return n;
}

function countByLabel(label: string, el: Element): number {
  let n = 0;
  rootOf(el)
    .querySelectorAll('input:not([type=hidden]), select, textarea, [role=combobox], [role=textbox], [role=checkbox], [role=switch], [role=radio]')
    .forEach((c) => {
      if (associatedLabel(c) === label && isVisible(c)) n++;
    });
  return n;
}

export function isVisible(el: Element): boolean {
  const html = el as HTMLElement;
  if (typeof html.checkVisibility === 'function') {
    if (!html.checkVisibility({ opacityProperty: false, visibilityProperty: true })) {
      // Les cases à cocher Material sont souvent visuellement masquées mais actives.
      return el.matches('input[type=checkbox], input[type=radio]') && !!el.parentElement && isVisible(el.parentElement);
    }
    return true;
  }
  const r = el.getBoundingClientRect();
  return r.width > 0 && r.height > 0;
}

/** Choisit le meilleur localisateur pour un élément, façon Playwright codegen. */
export function bestLocator(el: Element, css: string): Locator {
  for (const a of TEST_ATTRS) {
    const v = el.getAttribute(a);
    if (v && isUnique(attrSel('', a, v), el)) return { by: 'testid', attr: a, value: v };
  }
  const role = implicitRole(el);
  const isField = el.matches('input:not([type=button]):not([type=submit]):not([type=reset]):not([type=image]), select, textarea') ||
    ['textbox', 'combobox', 'checkbox', 'radio', 'switch', 'slider', 'spinbutton', 'searchbox'].includes(role);
  if (isField) {
    const label = associatedLabel(el);
    if (label && label.length <= 80 && countByLabel(label, el) === 1) return { by: 'label', value: label };
    const ph = el.getAttribute('placeholder');
    if (ph && rootOf(el).querySelectorAll(attrSel('', 'placeholder', ph)).length === 1) return { by: 'placeholder', value: ph };
  }
  if (role && !['generic', 'presentation', 'none', 'textbox'].includes(role)) {
    const name = accessibleName(el);
    if (name && name.length <= 80 && countByRole(role, name, el) === 1) return { by: 'role', role, name };
  }
  return { by: 'css', value: css };
}

/**
 * Libellé tel que Playwright getByLabel le voit : aria-labelledby, aria-label,
 * <label for> ou <label> englobant (Angular Material lie mat-label via <label for>).
 */
export function associatedLabel(el: Element): string {
  const root = rootOf(el);
  const lb = el.getAttribute('aria-labelledby');
  if (lb) {
    const t = textOfIds(lb, root);
    if (t) return t;
  }
  const al = el.getAttribute('aria-label');
  if (al) return clean(al);
  const labels = (el as HTMLInputElement).labels;
  if (labels && labels.length) return clean(Array.from(labels).map((l) => visibleText(l)).join(' ')).replace(/\s*\*$/, '');
  const wrap = el.closest('label');
  return wrap ? visibleText(wrap) : '';
}

function isFieldLike(el: Element): boolean {
  return (
    el.matches('input, select, textarea, [contenteditable=""], [contenteditable=true]') ||
    ['textbox', 'combobox', 'checkbox', 'radio', 'switch', 'slider', 'spinbutton', 'searchbox', 'listbox'].includes(implicitRole(el))
  );
}

export function describeTarget(el: Element): ElementTarget {
  const css = cssSelector(el);
  const role = implicitRole(el) || undefined;
  const target: ElementTarget = {
    css,
    locator: bestLocator(el, css),
    tag: el.tagName.toLowerCase(),
    role,
    label: (isFieldLike(el) ? fieldLabel(el) : '') || undefined,
    text: visibleText(el, 80) || undefined,
  };
  if (window.top !== window) target.frameUrl = location.href;
  return target;
}

/** Valeur courante d'un contrôle (natif ou composant ARIA type Angular Material). */
export function controlValue(el: Element): { value: string; raw?: string | boolean } {
  if (el instanceof HTMLInputElement) {
    if (el.type === 'checkbox' || el.type === 'radio') return { value: el.checked ? 'coché' : 'non coché', raw: el.checked };
    return { value: el.value, raw: el.value };
  }
  if (el instanceof HTMLTextAreaElement) return { value: el.value, raw: el.value };
  if (el instanceof HTMLSelectElement) {
    const opts = Array.from(el.selectedOptions);
    return { value: clean(opts.map((o) => o.text).join(', ')), raw: opts.map((o) => o.value).join(',') };
  }
  const role = implicitRole(el);
  if (['checkbox', 'switch', 'radio', 'menuitemcheckbox', 'menuitemradio'].includes(role)) {
    const c = el.getAttribute('aria-checked') === 'true';
    return { value: c ? 'coché' : 'non coché', raw: c };
  }
  if (['slider', 'spinbutton', 'progressbar', 'meter'].includes(role)) {
    const v = el.getAttribute('aria-valuetext') || el.getAttribute('aria-valuenow') || '';
    return { value: v, raw: v };
  }
  if (role === 'combobox') {
    // mat-select affiche la valeur dans .mat-mdc-select-value-text
    const vt = el.querySelector('.mat-mdc-select-value-text, .mat-select-value-text, [class*="value-text"]');
    const t = vt ? visibleText(vt) : visibleText(el);
    const ph = el.querySelector('.mat-mdc-select-placeholder, .mat-select-placeholder');
    return { value: ph && !vt ? '' : t, raw: ph && !vt ? '' : t };
  }
  if ((el as HTMLElement).isContentEditable) {
    const t = clean((el as HTMLElement).innerText, 2000);
    return { value: t, raw: t };
  }
  const t = visibleText(el);
  return { value: t, raw: t };
}
