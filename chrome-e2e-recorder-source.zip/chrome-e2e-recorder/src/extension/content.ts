/**
 * Content script : enregistre les interactions de l'utilisateur et gère la
 * sélection de zone. Injecté dans toutes les pages et iframes.
 */
import { DEFAULT_STATE, STATE_KEY, uid, type Message, type RecorderState, type Step, type StepType } from '../shared/types';
import { controlValue, describeTarget, interactiveAncestor } from './dom';
import { cancelRegion, OVERLAY_HOST_ID, selectRegion } from './region';
import { replayStep } from './replay';
import { extractEntries } from './snapshot';

declare global {
  interface Window {
    __e2eRecorderLoaded?: boolean;
  }
}

if (!window.__e2eRecorderLoaded) {
  window.__e2eRecorderLoaded = true;
  init();
}

function init(): void {
  let state: RecorderState = DEFAULT_STATE;
  const active = () => state.recording && !state.paused && !state.selecting;

  chrome.storage.local.get(STATE_KEY).then((r) => {
    if (r[STATE_KEY]) state = { ...DEFAULT_STATE, ...r[STATE_KEY] };
  });
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area === 'local' && changes[STATE_KEY]?.newValue) state = { ...DEFAULT_STATE, ...changes[STATE_KEY].newValue };
  });

  const send = (msg: Message) => {
    try {
      chrome.runtime.sendMessage(msg).catch(() => undefined);
    } catch {
      // Contexte d'extension invalidé (rechargement de l'extension) : on se tait.
    }
  };

  const ours = (e: Event) => e.composedPath().some((n) => (n as Element).id === OVERLAY_HOST_ID);
  const realTarget = (e: Event): Element | null => {
    const t = e.composedPath()[0];
    return t instanceof Element ? t : t instanceof Text ? t.parentElement : null;
  };

  const emit = (type: StepType, el: Element | null, extra: Partial<Step> = {}) => {
    const step: Step = {
      id: uid(),
      type,
      timestamp: Date.now(),
      url: location.href,
      title: document.title,
      ...(el ? { target: describeTarget(el) } : {}),
      ...extra,
    };
    send({ kind: 'step', step });
  };

  // --- Saisie : on regroupe les frappes et on émet la valeur finale. ---
  const pending = new Map<Element, ReturnType<typeof setTimeout>>();
  const isPassword = (el: Element) => el instanceof HTMLInputElement && el.type === 'password';

  const flushInput = (el: Element) => {
    const t = pending.get(el);
    if (t === undefined) return;
    clearTimeout(t);
    pending.delete(el);
    const { value } = controlValue(el);
    const masked = state.settings.maskPasswords && isPassword(el);
    emit('input', el, { value: masked ? '' : value, masked: masked || undefined });
  };
  const flushAll = () => Array.from(pending.keys()).forEach(flushInput);

  const textual = (el: Element) =>
    (el instanceof HTMLInputElement && !['checkbox', 'radio', 'file', 'range', 'color', 'button', 'submit', 'reset', 'image'].includes(el.type)) ||
    el instanceof HTMLTextAreaElement ||
    (el as HTMLElement).isContentEditable;

  document.addEventListener(
    'input',
    (e) => {
      if (!e.isTrusted || !active() || ours(e)) return;
      let el = realTarget(e);
      if (!el) return;
      if ((el as HTMLElement).isContentEditable) el = (el as HTMLElement).closest('[contenteditable]:not([contenteditable=false])') ?? el;
      if (!textual(el)) return;
      const prev = pending.get(el);
      if (prev !== undefined) clearTimeout(prev);
      const target = el;
      pending.set(el, setTimeout(() => flushInput(target), 1500));
    },
    true,
  );

  document.addEventListener(
    'change',
    (e) => {
      if (!e.isTrusted || !active() || ours(e)) return;
      const el = realTarget(e);
      if (!el) return;
      if (textual(el)) return flushInput(el);
      flushAll();
      if (el instanceof HTMLSelectElement) {
        const opts = Array.from(el.selectedOptions);
        emit('select', el, { value: opts.map((o) => o.value).join(','), key: opts.map((o) => o.text.trim()).join(',') });
      } else if (el instanceof HTMLInputElement && (el.type === 'checkbox' || el.type === 'radio')) {
        emit('check', el, { checked: el.checked });
      } else if (el instanceof HTMLInputElement && el.type === 'file') {
        emit('input', el, { value: Array.from(el.files ?? []).map((f) => f.name).join(', '), key: 'file' });
      } else if (el instanceof HTMLInputElement) {
        emit('input', el, { value: el.value });
      }
    },
    true,
  );

  document.addEventListener('focusout', (e) => {
    const el = realTarget(e);
    if (el && pending.has(el)) flushInput(el);
  }, true);

  // --- Clics ---
  const onClick = (e: MouseEvent, type: 'click' | 'dblclick') => {
    if (!e.isTrusted || !active() || ours(e)) return;
    const raw = realTarget(e);
    if (!raw) return;
    const el = interactiveAncestor(raw);
    // Gérés par l'événement change.
    if (el instanceof HTMLSelectElement || el instanceof HTMLOptionElement) return;
    if (el instanceof HTMLInputElement && ['checkbox', 'radio', 'file'].includes(el.type)) return;
    if (el instanceof HTMLLabelElement) {
      const ctrl = el.control;
      if (ctrl instanceof HTMLInputElement && ['checkbox', 'radio', 'file'].includes(ctrl.type)) return;
      if (ctrl && textual(ctrl)) return;
    }
    // Un clic dans un champ déjà focalisé n'apporte rien.
    if (textual(el) && document.activeElement === el && type === 'click' && pending.has(el)) return;
    flushAll();
    emit(type, el, e.button === 0 ? {} : { key: `button${e.button}` });
  };
  document.addEventListener('click', (e) => onClick(e, 'click'), true);
  document.addEventListener('dblclick', (e) => onClick(e, 'dblclick'), true);
  document.addEventListener('auxclick', (e) => e.button === 2 || onClick(e, 'click'), true);

  // --- Touches spéciales ---
  const KEYS = new Set(['Enter', 'Escape', 'Tab', 'ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight', 'PageUp', 'PageDown', 'Home', 'End', 'Delete', 'Backspace', 'F2']);
  document.addEventListener(
    'keydown',
    (e) => {
      if (!e.isTrusted || !active() || ours(e) || e.repeat) return;
      const el = realTarget(e);
      const mod = e.ctrlKey || e.metaKey || e.altKey;
      const inText = el && textual(el);
      if (!KEYS.has(e.key) && !(mod && e.key.length === 1)) return;
      // Retour arrière / flèches gauche-droite dans un champ : déjà couverts par la saisie.
      // Flèches dans une liste native : la sélection est enregistrée par « change ».
      if (el instanceof HTMLSelectElement && !mod && e.key !== 'Enter' && e.key !== 'Escape' && e.key !== 'Tab') return;
      if (inText && ['Backspace', 'Delete', 'ArrowLeft', 'ArrowRight', 'Home', 'End'].includes(e.key) && !mod) return;
      if (mod && ['c', 'v', 'x', 'a', 'z'].includes(e.key.toLowerCase()) && inText) return;
      if (el) flushInput(el);
      flushAll();
      const combo = [e.ctrlKey && 'Control', e.metaKey && 'Meta', e.altKey && 'Alt', e.shiftKey && e.key.length > 1 && 'Shift', e.key]
        .filter(Boolean)
        .join('+');
      emit('keypress', el && el !== document.body ? el : null, { key: combo });
    },
    true,
  );

  document.addEventListener(
    'submit',
    (e) => {
      if (!e.isTrusted || !active()) return;
      flushAll();
      emit('submit', realTarget(e));
    },
    true,
  );

  window.addEventListener('pagehide', flushAll);

  // --- Sélection de zone (cadre principal uniquement) ---
  chrome.runtime.onMessage.addListener((msg: Message, _sender, sendResponse) => {
    if (msg.kind === 'ping') {
      sendResponse({ ok: true, top: window.top === window });
      return undefined;
    }
    if (window.top !== window) return undefined;
    if (msg.kind === 'replay-step') {
      replayStep(msg.step, msg.password, msg.timeout).then(sendResponse, (e: Error) => sendResponse({ ok: false, message: e.message }));
      return true;
    }
    if (msg.kind === 'start-selection') {
      flushAll();
      runSelection();
      sendResponse({ ok: true });
    } else if (msg.kind === 'stop-selection') {
      cancelRegion();
    }
    return undefined;
  });

  async function runSelection() {
    const res = await selectRegion();
    if (!res) {
      send({ kind: 'selection-ended' });
      return;
    }
    const entries = extractEntries(res.rect, document.body, state.settings.maskPasswords);
    const container = res.element ? describeTarget(res.element) : undefined;
    const heading =
      res.element?.querySelector('h1,h2,h3,h4,h5,h6,legend,mat-card-title,[role=heading]')?.textContent?.trim() ||
      entries.find((e) => e.label === 'Titre')?.value;
    const name =
      heading ||
      res.element?.getAttribute('aria-label') ||
      container?.label ||
      (container?.text && container.text.length <= 40 ? container.text : '') ||
      `Zone ${Math.round(res.rect.width)}×${Math.round(res.rect.height)}`;
    // Laisse le temps au calque de disparaître avant la capture d'écran.
    await new Promise((r) => requestAnimationFrame(() => requestAnimationFrame(r)));
    send({
      kind: 'snapshot',
      url: location.href,
      title: document.title,
      viewportWidth: window.innerWidth,
      snapshot: {
        name,
        rect: res.rect,
        container,
        entries,
      },
    });
  }
}
