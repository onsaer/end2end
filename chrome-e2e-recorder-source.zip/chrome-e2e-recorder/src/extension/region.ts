/**
 * Calque de sélection de zone : glisser pour tracer un rectangle,
 * ou cliquer sur un élément (↑ pour remonter au parent), Échap pour annuler.
 */
import type { Rect } from '../shared/types';

export const OVERLAY_HOST_ID = '__e2e-recorder-overlay__';

export interface RegionResult {
  rect: Rect;
  element?: Element;
}

export function selectRegion(): Promise<RegionResult | null> {
  document.getElementById(OVERLAY_HOST_ID)?.remove();

  const host = document.createElement('div');
  host.id = OVERLAY_HOST_ID;
  host.style.cssText = 'all: initial; position: fixed; inset: 0; z-index: 2147483647;';
  const shadow = host.attachShadow({ mode: 'closed' });
  shadow.innerHTML = `
    <style>
      .layer { position: fixed; inset: 0; cursor: crosshair; }
      .hint {
        position: fixed; top: 12px; left: 50%; transform: translateX(-50%);
        background: #1f2330; color: #fff; font: 13px/1.4 system-ui, sans-serif;
        padding: 8px 14px; border-radius: 8px; box-shadow: 0 4px 16px rgba(0,0,0,.3);
        pointer-events: none; white-space: nowrap;
      }
      .hint b { color: #ff8a80; }
      .box {
        position: fixed; border: 2px solid #e53935; background: rgba(229,57,53,.12);
        pointer-events: none; display: none; box-sizing: border-box;
      }
      .box.hover { border-style: dashed; border-color: #1e88e5; background: rgba(30,136,229,.10); }
      .tag {
        position: absolute; left: -2px; top: -22px; background: #1e88e5; color: #fff;
        font: 11px/1.6 ui-monospace, monospace; padding: 0 6px; border-radius: 3px 3px 0 0; white-space: nowrap;
      }
    </style>
    <div class="layer"></div>
    <div class="box"><span class="tag"></span></div>
    <div class="hint"><b>Sélection de zone</b> · glissez pour tracer · cliquez sur un élément · ↑ parent · Échap annuler</div>
  `;
  (document.body || document.documentElement).appendChild(host);

  const box = shadow.querySelector('.box') as HTMLDivElement;
  const tag = shadow.querySelector('.tag') as HTMLSpanElement;

  let start: { x: number; y: number } | null = null;
  let hovered: Element | null = null;
  let current: Rect | null = null;

  const show = (r: Rect, hover: boolean, label = '') => {
    box.style.display = 'block';
    box.classList.toggle('hover', hover);
    Object.assign(box.style, { left: r.x + 'px', top: r.y + 'px', width: r.width + 'px', height: r.height + 'px' });
    tag.textContent = label;
    tag.style.display = label ? 'block' : 'none';
  };

  const elementAt = (x: number, y: number): Element | null =>
    document.elementsFromPoint(x, y).find((e) => e !== host && e !== document.documentElement && e !== document.body) ?? null;

  const describe = (el: Element) => {
    const id = el.id ? '#' + el.id : '';
    const cls = Array.from(el.classList).slice(0, 2).map((c) => '.' + c).join('');
    return el.tagName.toLowerCase() + id + cls;
  };

  const hover = (el: Element | null) => {
    hovered = el;
    if (!el) {
      box.style.display = 'none';
      return;
    }
    const r = el.getBoundingClientRect();
    show({ x: r.left, y: r.top, width: r.width, height: r.height }, true, describe(el));
  };

  return new Promise((resolve) => {
    const finish = (res: RegionResult | null) => {
      window.removeEventListener('keydown', onKey, true);
      host.remove();
      resolve(res);
    };

    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        e.preventDefault();
        e.stopImmediatePropagation();
        finish(null);
      } else if (e.key === 'ArrowUp' && hovered?.parentElement && hovered.parentElement !== document.documentElement) {
        e.preventDefault();
        e.stopImmediatePropagation();
        hover(hovered.parentElement);
      } else if (e.key === 'Enter' && hovered) {
        e.preventDefault();
        e.stopImmediatePropagation();
        const r = hovered.getBoundingClientRect();
        finish({ rect: { x: r.left, y: r.top, width: r.width, height: r.height }, element: hovered });
      }
    };
    window.addEventListener('keydown', onKey, true);

    const layer = shadow.querySelector('.layer') as HTMLDivElement;
    layer.addEventListener('mousedown', (e) => {
      e.preventDefault();
      start = { x: e.clientX, y: e.clientY };
    });
    layer.addEventListener('mousemove', (e) => {
      if (start && (Math.abs(e.clientX - start.x) > 4 || Math.abs(e.clientY - start.y) > 4)) {
        current = {
          x: Math.min(start.x, e.clientX),
          y: Math.min(start.y, e.clientY),
          width: Math.abs(e.clientX - start.x),
          height: Math.abs(e.clientY - start.y),
        };
        hovered = null;
        show(current, false, `${Math.round(current.width)} × ${Math.round(current.height)}`);
      } else if (!start) {
        const el = elementAt(e.clientX, e.clientY);
        if (el !== hovered) hover(el);
      }
    });
    layer.addEventListener('mouseup', (e) => {
      if (!start) return;
      start = null;
      if (current) {
        const r = current;
        current = null;
        finish({ rect: r });
        return;
      }
      const el = hovered ?? elementAt(e.clientX, e.clientY);
      if (el) {
        const r = el.getBoundingClientRect();
        finish({ rect: { x: r.left, y: r.top, width: r.width, height: r.height }, element: el });
      }
    });
    layer.addEventListener('wheel', () => hovered && hover(hovered), { passive: true });
    // Expose l'annulation à l'appelant via un événement personnalisé.
    host.addEventListener('e2e-cancel', () => finish(null));
  });
}

export function cancelRegion(): void {
  document.getElementById(OVERLAY_HOST_ID)?.dispatchEvent(new Event('e2e-cancel'));
}
