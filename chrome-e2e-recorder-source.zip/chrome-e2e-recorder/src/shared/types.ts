/**
 * Modèle de données partagé entre le content script, le service worker
 * et le panneau latéral Angular.
 */

export type StepType =
  | 'navigate'
  | 'click'
  | 'dblclick'
  | 'input'
  | 'select'
  | 'check'
  | 'keypress'
  | 'submit'
  | 'snapshot';

/** Localisateur structuré, traduit ensuite en Playwright / Cypress. */
export type Locator =
  | { by: 'testid'; attr: string; value: string }
  | { by: 'role'; role: string; name: string }
  | { by: 'label'; value: string }
  | { by: 'placeholder'; value: string }
  | { by: 'text'; value: string }
  | { by: 'css'; value: string };

export interface ElementTarget {
  /** Sélecteur CSS unique dans le document (ou la shadow root). */
  css: string;
  /** Meilleur localisateur « lisible » (testid, rôle, label…). */
  locator: Locator;
  tag: string;
  role?: string;
  label?: string;
  text?: string;
  /** URL du frame si l'événement vient d'une iframe. */
  frameUrl?: string;
}

export type SnapshotKind =
  | 'input'
  | 'textarea'
  | 'select'
  | 'checkbox'
  | 'radio'
  | 'combobox'
  | 'slider'
  | 'editable'
  | 'pair'
  | 'table'
  | 'text';

export interface SnapshotEntry {
  id: string;
  kind: SnapshotKind;
  label: string;
  /** Valeur lisible (texte affiché, texte de l'option, « coché »…). */
  value: string;
  /** Valeur brute utile pour les assertions (value d'un <select>, booléen…). */
  raw?: string | boolean;
  target: ElementTarget;
}

export interface Rect {
  x: number;
  y: number;
  width: number;
  height: number;
}

export interface Snapshot {
  name: string;
  rect: Rect;
  /** Présent si la zone correspond à un élément (clic plutôt que glisser). */
  container?: ElementTarget;
  entries: SnapshotEntry[];
  /** Capture PNG recadrée de la zone (data URL). */
  screenshot?: string;
}

export interface Step {
  id: string;
  type: StepType;
  timestamp: number;
  url: string;
  title?: string;
  target?: ElementTarget;
  value?: string;
  checked?: boolean;
  key?: string;
  /** Navigation provoquée par une action (lien, SPA) plutôt que saisie d'URL. */
  implicit?: boolean;
  masked?: boolean;
  snapshot?: Snapshot;
}

export interface Settings {
  maskPasswords: boolean;
  recordNavigation: boolean;
  /** Pause entre deux étapes rejouées (ms). */
  replayDelay: number;
  /** Arrête le rejeu dès qu'une action échoue. */
  stopOnFailure: boolean;
}

export type ReplayStatus = 'running' | 'ok' | 'fail' | 'skipped';

export interface EntryCheck {
  entryId: string;
  ok: boolean;
  actual: string;
}

export interface StepResult {
  status: ReplayStatus;
  message?: string;
  checks?: EntryCheck[];
}

export interface ReplayState {
  running: boolean;
  tabId?: number;
  current?: number;
  startedAt?: number;
  finishedAt?: number;
  stopped?: boolean;
  results: Record<string, StepResult>;
}

export interface RecorderState {
  recording: boolean;
  paused: boolean;
  selecting: boolean;
  tabId?: number;
  startedAt?: number;
  steps: Step[];
  settings: Settings;
  replay?: ReplayState;
}

export const DEFAULT_STATE: RecorderState = {
  recording: false,
  paused: false,
  selecting: false,
  steps: [],
  settings: { maskPasswords: true, recordNavigation: true, replayDelay: 300, stopOnFailure: true },
};

export const STATE_KEY = 'e2eRecorderState';

/** Messages échangés via chrome.runtime. */
export type Message =
  | { kind: 'start'; tabId: number }
  | { kind: 'stop' }
  | { kind: 'pause'; paused: boolean }
  | { kind: 'clear' }
  | { kind: 'select-region'; tabId?: number }
  | { kind: 'cancel-selection' }
  | { kind: 'delete-step'; id: string }
  | { kind: 'delete-entry'; stepId: string; entryId: string }
  | { kind: 'rename-snapshot'; stepId: string; name: string }
  | { kind: 'import'; steps: Step[] }
  | { kind: 'settings'; settings: Partial<Settings> }
  | { kind: 'replay-start'; tabId: number; password?: string; fromIndex?: number }
  | { kind: 'replay-stop' }
  // content -> background
  | { kind: 'step'; step: Step }
  | { kind: 'snapshot'; snapshot: Snapshot; url: string; title: string; viewportWidth: number }
  | { kind: 'selection-ended' }
  | { kind: 'ping' }
  // background -> content
  | { kind: 'start-selection' }
  | { kind: 'stop-selection' }
  | { kind: 'replay-step'; step: Step; password?: string; timeout: number };

/** Réponse du content script à une étape rejouée. */
export interface ReplayResponse {
  ok: boolean;
  message?: string;
  checks?: EntryCheck[];
  skipped?: boolean;
}

export function uid(): string {
  return Date.now().toString(36) + Math.random().toString(36).slice(2, 8);
}
