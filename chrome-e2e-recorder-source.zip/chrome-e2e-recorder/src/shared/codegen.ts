/**
 * Génération de scripts de test à partir des étapes enregistrées.
 */
import type { ElementTarget, Locator, SnapshotEntry, Step } from './types';

const q = (s: string) => JSON.stringify(s);

// ---------------------------------------------------------------- Playwright

function pwLocator(l: Locator, base = 'page'): string {
  switch (l.by) {
    case 'testid':
      return l.attr === 'data-testid' ? `${base}.getByTestId(${q(l.value)})` : `${base}.locator(${q(`[${l.attr}="${l.value}"]`)})`;
    case 'role':
      return `${base}.getByRole(${q(l.role)}, { name: ${q(l.name)}, exact: true })`;
    case 'label':
      return `${base}.getByLabel(${q(l.value)}, { exact: true })`;
    case 'placeholder':
      return `${base}.getByPlaceholder(${q(l.value)}, { exact: true })`;
    case 'text':
      return `${base}.getByText(${q(l.value)}, { exact: true })`;
    case 'css':
      return `${base}.locator(${q(l.value)})`;
  }
}

function pwTarget(t: ElementTarget | undefined): string {
  if (!t) return 'page.locator("body")';
  const base = t.frameUrl ? `page.frameLocator(${q(`iframe[src*="${new URL(t.frameUrl).pathname}"]`)})` : 'page';
  return pwLocator(t.locator, base);
}

/** Texte complet de l'élément (« Statut : Validé ») quand libellé et valeur y sont réunis. */
function fullText(e: SnapshotEntry): string {
  return typeof e.raw === 'string' && e.raw ? e.raw : e.value;
}

function pwAssertion(e: SnapshotEntry): string {
  const loc = pwTarget(e.target);
  switch (e.kind) {
    case 'input':
    case 'textarea':
      if (e.value === '••••••') return `// ${e.label} : mot de passe masqué`;
      return `await expect(${loc}).toHaveValue(${q(String(e.raw ?? e.value))});`;
    case 'select':
      return `await expect(${loc}).toHaveValue(${q(String(e.raw ?? ''))}); // ${e.value}`;
    case 'checkbox':
      return e.raw ? `await expect(${loc}).toBeChecked();` : `await expect(${loc}).not.toBeChecked();`;
    case 'radio':
      return e.value ? `await expect(${loc}).toBeChecked(); // ${e.label} = ${e.value}` : `// ${e.label} : aucune option choisie`;
    case 'slider':
      return `await expect(${loc}).toHaveAttribute("aria-valuenow", ${q(String(e.raw ?? e.value))});`;
    case 'combobox':
    case 'editable':
    case 'pair':
    case 'table':
    case 'text':
      return e.value ? `await expect(${loc}).toHaveText(${q(fullText(e))});` : `await expect(${loc}).toBeEmpty();`;
  }
}

export function toPlaywright(steps: Step[], testName = 'scénario enregistré'): string {
  const lines: string[] = [];
  let first = true;
  for (const s of steps) {
    switch (s.type) {
      case 'navigate':
        if (first || !s.implicit) lines.push(s.key === 'reload' ? 'await page.reload();' : `await page.goto(${q(s.url)});`);
        else lines.push("await page.waitForLoadState(); // navigation suivie, URL non comparée");
        break;
      case 'click':
        lines.push(`await ${pwTarget(s.target)}.click(${s.key === 'button1' ? "{ button: 'middle' }" : ''});`);
        break;
      case 'dblclick':
        lines.push(`await ${pwTarget(s.target)}.dblclick();`);
        break;
      case 'input':
        if (s.masked) lines.push(`await ${pwTarget(s.target)}.fill(process.env.E2E_PASSWORD ?? ''); // mot de passe masqué`);
        else if (s.key === 'file')
          lines.push(`await ${pwTarget(s.target)}.setInputFiles([${(s.value ?? '').split(', ').filter(Boolean).map(q).join(', ')}]); // chemins à adapter`);
        else lines.push(`await ${pwTarget(s.target)}.fill(${q(s.value ?? '')});`);
        break;
      case 'select':
        lines.push(`await ${pwTarget(s.target)}.selectOption(${q(s.value ?? '')}); // ${s.key ?? ''}`);
        break;
      case 'check':
        lines.push(`await ${pwTarget(s.target)}.${s.checked ? 'check' : 'uncheck'}();`);
        break;
      case 'keypress':
        lines.push(s.target ? `await ${pwTarget(s.target)}.press(${q(s.key ?? '')});` : `await page.keyboard.press(${q(s.key ?? '')});`);
        break;
      case 'submit':
        lines.push('// formulaire soumis');
        break;
      case 'snapshot': {
        const snap = s.snapshot!;
        if (lines[lines.length - 1] !== '') lines.push('');
        lines.push(`// Vérification de la zone « ${snap.name} » (${snap.entries.length} valeurs)`);
        if (snap.container) lines.push(`await expect(${pwTarget(snap.container)}).toBeVisible();`);
        for (const e of snap.entries) lines.push(`${pwAssertion(e)}${e.kind === 'text' || e.kind === 'pair' || e.kind === 'table' ? ` // ${e.label}` : ''}`);
        break;
      }
    }
    if (s.target?.frameUrl) lines[lines.length - 1] += ` // iframe : ${s.target.frameUrl}`;
    first = false;
  }
  return [
    "import { test, expect } from '@playwright/test';",
    '',
    `test(${q(testName)}, async ({ page }) => {`,
    ...lines.map((l) => (l ? '  ' + l : '')),
    '});',
    '',
  ].join('\n');
}

// ------------------------------------------------------------------- Cypress

function cyTarget(t: ElementTarget | undefined): string {
  if (!t) return 'cy.get("body")';
  const l = t.locator;
  if (l.by === 'testid') return `cy.get(${q(`[${l.attr}="${l.value}"]`)})`;
  if ((l.by === 'role' && ['button', 'link', 'tab', 'menuitem', 'option'].includes(l.role)) || l.by === 'text') {
    const name = l.by === 'role' ? l.name : l.value;
    if (t.text === name) return `cy.contains(${q(t.tag)}, ${q(name)})`;
  }
  return `cy.get(${q(t.css)})`;
}

function cyAssertion(e: SnapshotEntry): string {
  const loc = cyTarget(e.target);
  switch (e.kind) {
    case 'input':
    case 'textarea':
      if (e.value === '••••••') return `// ${e.label} : mot de passe masqué`;
      return `${loc}.should('have.value', ${q(String(e.raw ?? e.value))});`;
    case 'select':
      return `${loc}.should('have.value', ${q(String(e.raw ?? ''))}); // ${e.value}`;
    case 'checkbox':
      return e.target.tag === 'input'
        ? `${loc}.should('${e.raw ? 'be.checked' : 'not.be.checked'}');`
        : `${loc}.should('have.attr', 'aria-checked', '${e.raw ? 'true' : 'false'}');`;
    case 'radio':
      return e.value ? `${loc}.should('be.checked'); // ${e.label} = ${e.value}` : `// ${e.label} : aucune option choisie`;
    case 'slider':
      return `${loc}.should('have.attr', 'aria-valuenow', ${q(String(e.raw ?? e.value))});`;
    default:
      return `${loc}.invoke('text').then((t) => expect(t.replace(/\\s+/g, ' ').trim()).to.eq(${q(fullText(e))})); // ${e.label}`;
  }
}

export function toCypress(steps: Step[], testName = 'scénario enregistré'): string {
  const lines: string[] = [];
  let first = true;
  for (const s of steps) {
    switch (s.type) {
      case 'navigate':
        if (first || !s.implicit) lines.push(s.key === 'reload' ? 'cy.reload();' : `cy.visit(${q(s.url)});`);
        else lines.push('// navigation suivie, URL non comparée');
        break;
      case 'click':
        lines.push(`${cyTarget(s.target)}.click();`);
        break;
      case 'dblclick':
        lines.push(`${cyTarget(s.target)}.dblclick();`);
        break;
      case 'input':
        if (s.masked) lines.push(`${cyTarget(s.target)}.clear().type(Cypress.env('E2E_PASSWORD'), { log: false });`);
        else if (s.key === 'file') lines.push(`${cyTarget(s.target)}.selectFile([${(s.value ?? '').split(', ').filter(Boolean).map(q).join(', ')}]); // chemins à adapter`);
        else if (s.value) lines.push(`${cyTarget(s.target)}.clear().type(${q(s.value.replace(/[{}]/g, (c) => (c === '{' ? '{{}' : '}')))});`);
        else lines.push(`${cyTarget(s.target)}.clear();`);
        break;
      case 'select':
        lines.push(`${cyTarget(s.target)}.select(${q(s.value ?? '')});`);
        break;
      case 'check':
        lines.push(`${cyTarget(s.target)}.${s.checked ? 'check' : 'uncheck'}();`);
        break;
      case 'keypress': {
        const k = (s.key ?? '').split('+').map((p) => ({ Control: 'ctrl', Meta: 'cmd', Alt: 'alt', Shift: 'shift', ArrowUp: 'upArrow', ArrowDown: 'downArrow', ArrowLeft: 'leftArrow', ArrowRight: 'rightArrow', Escape: 'esc', Enter: 'enter', Tab: 'tab', Backspace: 'backspace', Delete: 'del', Home: 'home', End: 'end', PageUp: 'pageUp', PageDown: 'pageDown' })[p] ?? p.toLowerCase());
        lines.push(s.key === 'Tab' ? `cy.realPress('Tab'); // nécessite cypress-real-events` : `${s.target ? cyTarget(s.target) : 'cy.focused()'}.type('{${k.join('+')}}');`);
        break;
      }
      case 'submit':
        lines.push('// formulaire soumis');
        break;
      case 'snapshot': {
        const snap = s.snapshot!;
        if (lines[lines.length - 1] !== '') lines.push('');
        lines.push(`// Vérification de la zone « ${snap.name} » (${snap.entries.length} valeurs)`);
        for (const e of snap.entries) lines.push(cyAssertion(e));
        break;
      }
    }
    first = false;
  }
  return [`describe(${q(testName)}, () => {`, `  it('rejoue le parcours', () => {`, ...lines.map((l) => (l ? '    ' + l : '')), '  });', '});', ''].join('\n');
}

// ---------------------------------------------------------------- Descriptions

export function describeStep(s: Step): string {
  const who = s.target ? targetName(s.target) : '';
  switch (s.type) {
    case 'navigate':
      return s.key === 'reload' ? 'Rechargement de la page' : s.implicit ? `Navigation vers ${shortUrl(s.url)}` : `Ouverture de ${shortUrl(s.url)}`;
    case 'click':
      return `Clic sur ${who}`;
    case 'dblclick':
      return `Double-clic sur ${who}`;
    case 'input':
      return s.masked ? `Saisie masquée dans ${who}` : `Saisie « ${s.value} » dans ${who}`;
    case 'select':
      return `Choix « ${s.key || s.value} » dans ${who}`;
    case 'check':
      return `${s.checked ? 'Coche' : 'Décoche'} ${who}`;
    case 'keypress':
      return `Touche ${s.key}${who ? ' sur ' + who : ''}`;
    case 'submit':
      return `Soumission du formulaire`;
    case 'snapshot':
      return `Zone « ${s.snapshot?.name} » : ${s.snapshot?.entries.length ?? 0} libellés/valeurs`;
  }
}

function targetName(t: ElementTarget): string {
  const l = t.locator;
  const kind: Record<string, string> = {
    button: 'le bouton',
    link: 'le lien',
    checkbox: 'la case',
    radio: "l'option",
    tab: "l'onglet",
    option: "l'option",
    menuitem: "l'entrée de menu",
    combobox: 'la liste',
    textbox: 'le champ',
    switch: "l'interrupteur",
  };
  const k = kind[t.role ?? ''] ?? (t.tag === 'input' || t.tag === 'textarea' ? 'le champ' : '');
  const name = l.by === 'role' ? l.name : l.by === 'label' || l.by === 'placeholder' || l.by === 'text' ? l.value : t.label || t.text || '';
  if (name) return `${k ? k + ' ' : ''}« ${name.length > 50 ? name.slice(0, 49) + '…' : name} »`.trim();
  return `\`${t.css}\``;
}

function shortUrl(u: string): string {
  try {
    const url = new URL(u);
    return url.host + (url.pathname === '/' ? '' : url.pathname) + url.search + url.hash;
  } catch {
    return u;
  }
}
